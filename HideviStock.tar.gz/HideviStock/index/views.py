from django.shortcuts import render
from django.contrib import messages, auth

from apscheduler.triggers.cron import CronTrigger
from django.shortcuts import render, redirect
from django.template import loader, context
from django.http import HttpResponse,HttpResponseRedirect, HttpResponseNotFound
from django.apps import apps
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.clickjacking import xframe_options_sameorigin




# Create your views here.
@login_required
def index(request):
    if request.method == "POST":
        request.session['username'] = request.POST.get("username")
        return redirect("index:main")
    else:
        return redirect("user:login")



@login_required
@xframe_options_sameorigin
def main(request):
    template = loader.get_template('index/base.html')
    context={}
    return HttpResponse(template.render(context,request))
