#!/usr/bin/env python
# encoding: utf-8
from django.db import models
import django.db.models.options as options
from scheduler import choice
from django.utils.timezone import now

"""
这个接口可以获取到交易所的开盘日期
trade_cal(exchange='SSE', start_date='19900101', end_date='20190617', is_open='1')

trade_cal(exchange='SZSE', start_date='19900101', end_date='20190617', is_open='1')

任务控制器要在启动后交叉对比开盘日期来生成任务

fields 生成  ",".join([_f.split('\t')[0] for _f in f.split('\n')])

动态设置属性  obj.__dict__[attr] = val

access model meta  obj._meta.attr

6-23  数据结构大改，重新设置主键位置，丢弃auto字段
"""

# add customer meta attr
options.DEFAULT_NAMES = options.DEFAULT_NAMES + ('df_fields',)


# test 6ee61df740be5dda6e2ce49ad5265b9469cda46e4e6905a5f6551bea
class ApiSecret(models.Model):
    secret = models.CharField("API秘钥", max_length=100, null=False, blank=False, unique=True, db_index=True)
    weight = models.IntegerField("权重", default=1)
    memo = models.CharField("备注", max_length=300, null=True, blank=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)
    #
    class Meta:
        verbose_name = "API秘钥管理"
        verbose_name_plural = verbose_name

#
#
#class MarketSegmentsWind(models.Model):
#     name = models.CharField("Wind分类", max_length=100, null=False, blank=False, unique=True, db_index=True)
#     # update_time = models.DateTimeField("修改时间", default=now, editable=False)
#
#     class Meta:
#         ordering = ['pk']
#         verbose_name = "Wind行业"
#         verbose_name_plural = verbose_name
#
#     def __str__(self):
#         return "%s" % self.name
#
#     def __repr__(self):
#         return self.__str__()
#
#
#class MarketSegmentsCust1(models.Model):
#     name = models.CharField("行业细分1", max_length=100, null=False, blank=False, unique=True, db_index=True)
#     update_time = models.DateTimeField("修改时间", default=now, editable=False)
#
#     class Meta:
#         ordering = ['pk']
#         verbose_name = "自定义细分1"
#         verbose_name_plural = verbose_name
#
#     def __str__(self):
#         return "%s" % self.name
#
#     def __repr__(self):
#         return self.__str__()
#
#
#class MarketSegmentsCust2(models.Model):
#     name = models.CharField("行业细分2", max_length=100, null=False, blank=False, unique=True, db_index=True)
#     update_time = models.DateTimeField("修改时间", default=now, editable=False)
#
#     class Meta:
#         ordering = ['pk']
#         verbose_name = "自定义细分2"
#         verbose_name_plural = verbose_name
#
#     def __str__(self):
#         return "%s" % self.name
#
#     def __repr__(self):
#         return self.__str__()
#
#
class Basic(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=25
    获取方式 stock_basic(exchange='', fields='ts_code,symbol,name,area,industry,fullname,enname,market,exchange,curr_type,list_status,list_date,delist_date,is_hs')
    数据量 基本不增长 3600条

    ts_code str TS代码
    symbol str 股票代码
    name str 股票名称
    area str 所在地域
    industry str 所属行业
    fullname str 股票全称
    enname str 英文全称
    market str 市场类型 （主板 / 中小板 / 创业板）
    exchange str 交易所代码
    curr_type str 交易货币
    list_status str 上市状态： L上市 D退市 P暂停上市
    list_date str 上市日期
    delist_date str 退市日期
    is_hs str 是否沪深港通标的，N否 H沪股 S深股通

    """
    ts_code = models.CharField("TS代码", max_length=20, primary_key=True)
    symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, unique=True, db_index=True)
    name = models.CharField("股票名称", max_length=20, null=True, db_index=True)
    area = models.CharField("所在地域", max_length=20, null=True, db_index=True)
    industry = models.CharField("所属行业", max_length=20, null=True, db_index=True)
    fullname = models.CharField("股票全称", max_length=200, null=True)
    enname = models.CharField("英文全称", max_length=200, null=True)
    market = models.CharField("市场类型", max_length=10, null=True, db_index=True, choices=choice.basic_market)
    exchange = models.CharField("交易所代码", max_length=10, null=True, db_index=True, choices=choice.exchage_code)
    curr_type = models.CharField("交易货币", max_length=200, null=True)
    list_status = models.CharField("上市状态", max_length=2, null=True, db_index=True, choices=choice.basic_list_status)
    list_date = models.IntegerField("上市日期", null=True)
    delist_date = models.IntegerField("退市日期", null=True)
    is_hs = models.CharField("是否沪深港通标的", max_length=2, null=True, db_index=True, choices=choice.basic_is_hs)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)
    # market_segments_wind = models.ForeignKey('MarketSegmentsWind', verbose_name="Wind行业",
    #                                          on_delete=models.SET_NULL, null=True, db_index=True)
    # market_segments_cust1 = models.ForeignKey('MarketSegmentsCust1', verbose_name="自定义细分1",
    #                                           on_delete=models.SET_NULL, null=True, db_index=True)
    # market_segments_cust2 = models.ForeignKey('MarketSegmentsCust2', verbose_name="自定义细分2",
    #                                           on_delete=models.SET_NULL, null=True, db_index=True)

    class Meta:
        db_table = 'basic'
        verbose_name = '股票列表'
        verbose_name_plural = verbose_name
        ordering = ['ts_code']
        df_fields = 'ts_code,symbol,name,area,industry,fullname,enname,market,exchange,curr_type,list_status,' \
                    'list_date,delist_date,is_hs'

    def __str__(self):
        return "[%s] %s" % (self.__class__.__name__, self.ts_code)

    def __repr__(self):
        return self.__str__()


class NameChange(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=100
    获取方式 namechange(fields='ts_code,name,start_date,end_date,change_reason', ts_code='600600.SH')
    数据量 增长不会太频繁

    注： 不跟ts_code可以拿到所有的数据，但是从cli执行结果来看只有1万条数据，不知道是限制还是只有1万条
    以ts_code为维度并发拉数据

    ts_code	str	Y	TS代码
    name	str	Y	证券名称
    start_date	str	Y	开始日期
    end_date	str	Y	结束日期
    ann_date	str	Y	公告日期
    change_reason	str	Y	变更原因

    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    # symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, db_index=True)
    name = models.CharField("证券名称", max_length=20, null=True, db_index=True)
    start_date = models.IntegerField("开始日期", null=True, db_index=True)
    end_date = models.IntegerField("结束日期", null=True)
    ann_date = models.IntegerField("公告日期", null=True)
    change_reason = models.CharField("变更原因", max_length=100, null=True)
    #update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'namechange'
        verbose_name = '股票曾用名'
        df_fields = "ts_code,name,start_date,end_date,ann_date,change_reason"
        ordering = ['-start_date','ts_code']
        unique_together = ['ts_code', 'start_date','end_date','ann_date']

    def __str__(self):
        return "%s:%s" % (self.ts_code, self.start_date)

    def __repr__(self):
        return self.__str__()


class Daily(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=27
    获取方式 ts.daily(trade_date='20190617')
    数据量 一天3500条数据左右 (一年250个工作日，预计90W左右数据）

    以日期为维度并发拉数据

    ts_code	str	股票代码
    trade_date	str	交易日期
    open	float	开盘价
    high	float	最高价
    low	float	最低价
    close	float	收盘价
    pre_close	float	昨收价
    change	float	涨跌额
    pct_chg	float	涨跌幅 （未复权，如果是复权请用 通用行情接口 ）
    vol	float	成交量 （手）
    amount	float	成交额 （千元）

    此表数据庞大，建议分区
    alter table stock_daily PARTITION BY HASH (mod(primary_index, 12)) PARTITIONS 12;
    """
    primary_index = models.BigIntegerField("主索引(ts_code+trade_date)",auto_created=True, primary_key=True)
    ts_code = models.CharField("TS代码", max_length=20,  blank=False, db_index=True)
    # symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, db_index=True)
    trade_date = models.IntegerField("交易日期", db_index=True)
    open = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='开盘价', null=True)
    high = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='最高价', null=True)
    low = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='最低价', null=True)
    close = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='收盘价', null=True)
    pre_close = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='昨收价', null=True)
    change = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='涨跌额', null=True)
    pct_chg = models.DecimalField(max_digits=18, decimal_places=4, verbose_name='涨跌幅', null=True)
    vol = models.DecimalField(max_digits=18, decimal_places=2, verbose_name='成交量(手)', null=True)
    amount = models.DecimalField(max_digits=24, decimal_places=4, verbose_name='成交额(千元)', null=True)
    #update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'daily'
        verbose_name = '日线行情'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,trade_date,open,high,low,close,pre_close,change,pct_chg,vol,amount'
        ordering = ['-trade_date' ,'ts_code']
        unique_together = (('ts_code', 'trade_date'),)

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.trade_date)

    def __repr__(self):
        return self.__str__()


class DailyBasic(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=32
    获取方式 pro.daily_basic(ts_code='', trade_date='19911015')
    数据量 一天3500条数据左右 (一年250个工作日，预计90W左右数据）

    ts_code	str	TS股票代码
    trade_date	str	交易日期
    close	float	当日收盘价
    turnover_rate	float	换手率（%）
    turnover_rate_f	float	换手率（自由流通股）
    volume_ratio	float	量比
    pe	float	市盈率（总市值/净利润）
    pe_ttm	float	市盈率（TTM）
    pb	float	市净率（总市值/净资产）
    ps	float	市销率
    ps_ttm	float	市销率（TTM）
    total_share	float	总股本 （万股）
    float_share	float	流通股本 （万股）
    free_share	float	自由流通股本 （万）
    total_mv	float	总市值 （万元）
    circ_mv	float	流通市值（万元）

    此表数据庞大，建议分区
    alter table stock_dailybasic PARTITION BY HASH (mod(primary_index, 12)) PARTITIONS 12;
    """
    primary_index = models.BigIntegerField("主索引(ts_code+trade_date)",auto_created=True, primary_key=True)
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    # symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, db_index=True)
    trade_date = models.IntegerField("交易日期", db_index=True)
    close = models.DecimalField("当日收盘价", max_digits=18, decimal_places=2, null=True)
    turnover_rate = models.DecimalField("换手率(%)", max_digits=18, decimal_places=4, null=True)
    turnover_rate_f = models.DecimalField("换手率(自由流通股)", max_digits=18, decimal_places=4, null=True)
    volume_ratio = models.DecimalField("量比", max_digits=18, decimal_places=2, null=True)
    pe = models.DecimalField("市盈率(总市值/净利润)", max_digits=18, decimal_places=4, null=True)
    pe_ttm = models.DecimalField("市盈率(TTM)", max_digits=18, decimal_places=4, null=True)
    pb = models.DecimalField("市净率(总市值/净资产)", max_digits=18, decimal_places=4, null=True)
    ps = models.DecimalField("市销率", max_digits=18, decimal_places=4, null=True)
    ps_ttm = models.DecimalField("市销率(TTM)", max_digits=18, decimal_places=4, null=True)
    total_share = models.DecimalField("总股本(万股)", max_digits=18, decimal_places=4, null=True)
    float_share = models.DecimalField("流通股本(万股)", max_digits=18, decimal_places=4, null=True)
    free_share = models.DecimalField("自由流通股本(万)", max_digits=18, decimal_places=4, null=True)
    total_mv = models.DecimalField("总市值(万元)", max_digits=18, decimal_places=4, null=True)
    circ_mv = models.DecimalField("流通市值(万元)", max_digits=18, decimal_places=4, null=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'dailybasic'
        verbose_name = '每日指标'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,trade_date,close,turnover_rate,turnover_rate_f,volume_ratio,pe,pe_ttm,pb,ps,ps_ttm,' \
                    'total_share,float_share,free_share,total_mv,circ_mv'
        ordering = ['-trade_date' ,'ts_code']
        unique_together = (('ts_code', 'trade_date'),)

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.trade_date)

    def __repr__(self):
        return self.__str__()


class Income(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=33
    获取方式 ts.income(ts_code='000001.SZ')

    500积分+


    ts_code	str	Y	TS代码
    ann_date	str	Y	公告日期
    f_ann_date	str	Y	实际公告日期
    end_date	str	Y	报告期
    report_type	str	Y	报告类型 1合并报表 2单季合并 3调整单季合并表 4调整合并报表 5调整前合并报表 6母公司报表 7母公司单季表 8 母公司调整单季表 9母公司调整表 10母公司调整前报表 11调整前合并报表 12母公司调整前报表
    comp_type	str	Y	公司类型(1一般工商业2银行3保险4证券)
    basic_eps	float	Y	基本每股收益
    diluted_eps	float	Y	稀释每股收益
    total_revenue	float	Y	营业总收入
    revenue	float	Y	营业收入
    int_income	float	Y	利息收入
    prem_earned	float	Y	已赚保费
    comm_income	float	Y	手续费及佣金收入
    n_commis_income	float	Y	手续费及佣金净收入
    n_oth_income	float	Y	其他经营净收益
    n_oth_b_income	float	Y	加:其他业务净收益
    prem_income	float	Y	保险业务收入
    out_prem	float	Y	减:分出保费
    une_prem_reser	float	Y	提取未到期责任准备金
    reins_income	float	Y	其中:分保费收入
    n_sec_tb_income	float	Y	代理买卖证券业务净收入
    n_sec_uw_income	float	Y	证券承销业务净收入
    n_asset_mg_income	float	Y	受托客户资产管理业务净收入
    oth_b_income	float	Y	其他业务收入
    fv_value_chg_gain	float	Y	加:公允价值变动净收益
    invest_income	float	Y	加:投资净收益
    ass_invest_income	float	Y	其中:对联营企业和合营企业的投资收益
    forex_gain	float	Y	加:汇兑净收益
    total_cogs	float	Y	营业总成本
    oper_cost	float	Y	减:营业成本
    int_exp	float	Y	减:利息支出
    comm_exp	float	Y	减:手续费及佣金支出
    biz_tax_surchg	float	Y	减:营业税金及附加
    sell_exp	float	Y	减:销售费用
    admin_exp	float	Y	减:管理费用
    fin_exp	float	Y	减:财务费用
    assets_impair_loss	float	Y	减:资产减值损失
    prem_refund	float	Y	退保金
    compens_payout	float	Y	赔付总支出
    reser_insur_liab	float	Y	提取保险责任准备金
    div_payt	float	Y	保户红利支出
    reins_exp	float	Y	分保费用
    oper_exp	float	Y	营业支出
    compens_payout_refu	float	Y	减:摊回赔付支出
    insur_reser_refu	float	Y	减:摊回保险责任准备金
    reins_cost_refund	float	Y	减:摊回分保费用
    other_bus_cost	float	Y	其他业务成本
    operate_profit	float	Y	营业利润
    non_oper_income	float	Y	加:营业外收入
    non_oper_exp	float	Y	减:营业外支出
    nca_disploss	float	Y	其中:减:非流动资产处置净损失
    total_profit	float	Y	利润总额
    income_tax	float	Y	所得税费用
    n_income	float	Y	净利润(含少数股东损益)
    n_income_attr_p	float	Y	净利润(不含少数股东损益)
    minority_gain	float	Y	少数股东损益
    oth_compr_income	float	Y	其他综合收益
    t_compr_income	float	Y	综合收益总额
    compr_inc_attr_p	float	Y	归属于母公司(或股东)的综合收益总额
    compr_inc_attr_m_s	float	Y	归属于少数股东的综合收益总额
    ebit	float	Y	息税前利润
    ebitda	float	Y	息税折旧摊销前利润
    insurance_exp	float	Y	保险业务支出
    undist_profit	float	Y	年初未分配利润
    distable_profit	float	Y	可分配利润
    update_flag	str	N	更新标识
    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    ann_date = models.IntegerField("公告日期", db_index=True, null=True)
    f_ann_date = models.IntegerField("实际公告日期", db_index=True, null=True)
    end_date = models.IntegerField("报告期", db_index=True, null=True)
    report_type = models.IntegerField("报告类型", db_index=True, null=True, choices=choice.income_report_type)
    comp_type = models.IntegerField("公司类型", db_index=True, null=True, choices=choice.income_comp_type)
    basic_eps = models.DecimalField(max_digits=18, decimal_places=4,verbose_name="基本每股收益", null=True)
    diluted_eps = models.DecimalField(max_digits=18, decimal_places=4, verbose_name="稀释每股收益", null=True)
    total_revenue = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业总收入", null=True)
    revenue = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业收入", null=True)
    int_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="利息收入", null=True)
    prem_earned = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="已赚保费", null=True)
    comm_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="手续费及佣金收入", null=True)
    n_commis_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="手续费及佣金净收入", null=True)
    n_oth_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其他经营净收益", null=True)
    n_oth_b_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="加:其他业务净收益", null=True)
    prem_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="保险业务收入", null=True)
    out_prem = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:分出保费", null=True)
    une_prem_reser = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="提取未到期责任准备金", null=True)
    reins_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其中:分保费收入", null=True)
    n_sec_tb_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="代理买卖证券业务净收入", null=True)
    n_sec_uw_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="证券承销业务净收入", null=True)
    n_asset_mg_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="受托客户资产管理业务净收入", null=True)
    oth_b_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其他业务收入", null=True)
    fv_value_chg_gain = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="加:公允价值变动净收益", null=True)
    invest_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="加:投资净收益", null=True)
    ass_invest_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其中:对联营企业和合营企业的投资收益", null=True)
    forex_gain = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="加:汇兑净收益", null=True)
    total_cogs = models.DecimalField(max_digits=24, decimal_places=2,  verbose_name="营业总成本", null=True)
    oper_cost = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:营业成本", null=True)
    int_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:利息支出", null=True)
    comm_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:手续费及佣金支出", null=True)
    biz_tax_surchg = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:营业税金及附加", null=True)
    sell_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:销售费用", null=True)
    admin_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:管理费用", null=True)
    fin_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:财务费用", null=True)
    assets_impair_loss = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:资产减值损失", null=True)
    prem_refund = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="退保金", null=True)
    compens_payout = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="赔付总支出", null=True)
    reser_insur_liab = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="提取保险责任准备金", null=True)
    div_payt = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="保户红利支出", null=True)
    reins_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="分保费用", null=True)
    oper_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业支出", null=True)
    compens_payout_refu = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:摊回赔付支出", null=True)
    insur_reser_refu = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:摊回保险责任准备金", null=True)
    reins_cost_refund = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:摊回分保费用", null=True)
    other_bus_cost = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其他业务成本", null=True)
    operate_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业利润", null=True)
    non_oper_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="加:营业外收入", null=True)
    non_oper_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="减:营业外支出", null=True)
    nca_disploss = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其中:减:非流动资产处置净损失", null=True)
    total_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="利润总额", null=True)
    income_tax = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="所得税费用", null=True)
    n_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="净利润(含少数股东损益)", null=True)
    n_income_attr_p = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="净利润(不含少数股东损益)", null=True)
    minority_gain = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="少数股东损益", null=True)
    oth_compr_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="其他综合收益", null=True)
    t_compr_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="综合收益总额", null=True)
    compr_inc_attr_p = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="归属于母公司(或股东)的综合收益总额", null=True)
    compr_inc_attr_m_s = models.DecimalField(max_digits=24, decimal_places=2, verbose_name="归属于少数股东的综合收益总额", null=True)
    ebit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="息税前利润", null=True)
    ebitda = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="息税折旧摊销前利润", null=True)
    insurance_exp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="保险业务支出", null=True)
    undist_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="年初未分配利润", null=True)
    distable_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="可分配利润", null=True)
    update_flag = models.IntegerField("更新标识")
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'income'
        verbose_name = '利润表'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,f_ann_date,end_date,report_type,comp_type,basic_eps,diluted_eps,total_revenue,' \
                    'revenue,int_income,prem_earned,comm_income,n_commis_income,n_oth_income,n_oth_b_income,' \
                    'prem_income,out_prem,une_prem_reser,reins_income,n_sec_tb_income,n_sec_uw_income,' \
                    'n_asset_mg_income,oth_b_income,fv_value_chg_gain,invest_income,ass_invest_income,forex_gain,' \
                    'total_cogs,oper_cost,int_exp,comm_exp,biz_tax_surchg,sell_exp,admin_exp,fin_exp,' \
                    'assets_impair_loss,prem_refund,compens_payout,reser_insur_liab,div_payt,reins_exp,oper_exp,' \
                    'compens_payout_refu,insur_reser_refu,reins_cost_refund,other_bus_cost,operate_profit,' \
                    'non_oper_income,non_oper_exp,nca_disploss,total_profit,income_tax,n_income,n_income_attr_p,' \
                    'minority_gain,oth_compr_income,t_compr_income,compr_inc_attr_p,compr_inc_attr_m_s,ebit,ebitda,' \
                    'insurance_exp,undist_profit,distable_profit,update_flag'
        ordering = ['-end_date','-ann_date','ts_code']

    def __str__(self):
        type_display = self.report_type
        for c in choice.income_report_type:
            if type_display == int(c[0]):
                type_display = c[1]
        return "[%s] %s:%s:%s" % (self.__class__.__name__, self.ts_code, self.end_date, type_display)

    def __repr__(self):
        return self.__str__()


class Forecast(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=45
    获取方式 ts.forecast(ts_code='000001.SZ')


    600积分+

    ts_code	 str	TS股票代码
    ann_date	str	公告日期
    end_date	str	报告期
    type	str	业绩预告类型(预增/预减/扭亏/首亏/续亏/续盈/略增/略减)
    p_change_min	float	预告净利润变动幅度下限（%）
    p_change_max	float	预告净利润变动幅度上限（%）
    net_profit_min	float	预告净利润下限（万元）
    net_profit_max	float	预告净利润上限（万元）
    last_parent_net	float	上年同期归属母公司净利润
    first_ann_date	str	首次公告日
    summary	str	业绩预告摘要
    change_reason	str	业绩变动原因
    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    # symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, db_index=True)
    ann_date = models.IntegerField("公告日期", db_index=True, null=True)
    end_date = models.IntegerField("报告期", db_index=True, null=True)
    type = models.CharField("业绩预告类型", max_length=10, null=True, db_index=True, choices=choice.forecast_type)
    p_change_min = models.DecimalField(max_digits=24, decimal_places=4, verbose_name="预告净利润变动幅度下限（%）", null=True)
    p_change_max = models.DecimalField(max_digits=24, decimal_places=4, verbose_name="预告净利润变动幅度上限（%）", null=True)
    net_profit_min = models.DecimalField(max_digits=24, decimal_places=4,verbose_name="预告净利润下限（万元）", null=True)
    net_profit_max = models.DecimalField(max_digits=24, decimal_places=4,verbose_name="预告净利润上限（万元）", null=True)
    last_parent_net = models.DecimalField(max_digits=24, decimal_places=4, verbose_name="上年同期归属母公司净利润", null=True)
    first_ann_date = models.IntegerField("首次公告日", null=True)
    summary = models.CharField("业绩预告摘要", max_length=500, null=True)
    change_reason = models.TextField("业绩变动原因", null=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'forecast'
        verbose_name = '业绩预告'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,end_date,type,p_change_min,p_change_max,net_profit_min,net_profit_max,' \
                    'last_parent_net,first_ann_date,summary,change_reason'
        ordering = ['-end_date', '-ann_date','ts_code']

    def __str__(self):
        type_display = self.type
        return "[%s] %s:%s:%s" % (self.__class__.__name__, self.ts_code, self.end_date, type_display)

    def __repr__(self):
        return self.__str__()


class Express(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=46
    获取方式 pro.express(ts_code='600000.SH', fields='ts_code,ann_date,end_date,revenue,operate_profit,total_profit,n_income,total_assets,total_hldr_eqy_exc_min_int,diluted_eps,diluted_roe,yoy_net_profit,bps,yoy_sales,yoy_op,yoy_tp,yoy_dedu_np,yoy_eps,yoy_roe,growth_assets,yoy_equity,growth_bps,or_last_year,op_last_year,tp_last_year,np_last_year,eps_last_year,open_net_assets,open_bps,perf_summary,is_audit,remark')
    500积分+

    ts_code	str	TS股票代码
    ann_date	str	公告日期
    end_date	str	报告期
    revenue	float	营业收入(元)
    operate_profit	float	营业利润(元)
    total_profit	float	利润总额(元)
    n_income	float	净利润(元)
    total_assets	float	总资产(元)
    total_hldr_eqy_exc_min_int	float
    diluted_eps	float	每股收益(摊薄)(元)
    diluted_roe	float	净资产收益率(摊薄)(%)
    yoy_net_profit	float	去年同期修正后净利润
    bps	float	每股净资产
    yoy_sales	float	同比增长率:营业收入
    yoy_op	float	同比增长率:营业利润
    yoy_tp	float	同比增长率:利润总额
    yoy_dedu_np	float	同比增长率:归属母公司股东的净利润
    yoy_eps	float	同比增长率:基本每股收益
    yoy_roe	float	同比增减:加权平均净资产收益率
    growth_assets	float	比年初增长率:总资产
    yoy_equity	float	比年初增长率:归属母公司的股东权益
    growth_bps	float	比年初增长率:归属于母公司股东的每股净资产
    or_last_year	float	去年同期营业收入
    op_last_year	float	去年同期营业利润
    tp_last_year	float	去年同期利润总额
    np_last_year	float	去年同期净利润
    eps_last_year	float	去年同期每股收益
    open_net_assets	float	期初净资产
    open_bps	float	期初每股净资产
    perf_summary	str	业绩简要说明
    is_audit	int	是否审计： 1是 0否
    remark	str	备注

    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    # symbol = models.CharField("股票代码", max_length=20, null=False, blank=False, db_index=True)
    ann_date = models.IntegerField("公告日期", db_index=True)
    end_date = models.IntegerField("报告期", db_index=True)
    revenue = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业收入", null=True)
    operate_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="营业利润", null=True)
    total_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="利润总额", null=True)
    n_income = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="净利润", null=True)
    total_assets = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="总资产", null=True)
    total_hldr_eqy_exc_min_int = models.DecimalField(max_digits=18, decimal_places=4, verbose_name="股东权益合计(不含少数股东权益)(元)", null=True)
    diluted_eps = models.DecimalField(max_digits=24, decimal_places=4, verbose_name="每股收益(摊薄)(元)", null=True)
    diluted_roe = models.DecimalField(max_digits=18, decimal_places=4, verbose_name="净资产收益率(摊薄)(%)", null=True)
    yoy_net_profit = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="去年同期修正后净利润", null=True)
    bps = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="每股净资产", null=True)
    yoy_sales = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增长率:营业收入", null=True)
    yoy_op = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增长率:营业利润", null=True)
    yoy_tp = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增长率:利润总额", null=True)
    yoy_dedu_np = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增长率:归属母公司股东的净利润", null=True)
    yoy_eps = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增长率:基本每股收益", null=True)
    yoy_roe = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="同比增减:加权平均净资产收益率", null=True)
    growth_assets = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="比年初增长率:总资产", null=True)
    yoy_equity = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="比年初增长率:归属母公司的股东权益", null=True)
    growth_bps = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="比年初增长率:归属于母公司股东的每股净资产", null=True)
    or_last_year = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="去年同期营业收入", null=True)
    op_last_year = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="去年同期营业利润", null=True)
    tp_last_year = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="去年同期利润总额", null=True)
    np_last_year = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="去年同期每股收益", null=True)
    eps_last_year = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="期初净资产", null=True)
    open_net_assets = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="期初净资产", null=True)
    open_bps = models.DecimalField(max_digits=18, decimal_places=2, verbose_name="期初每股净资产", null=True)
    perf_summary = models.TextField("业绩简要说明", null=True)
    is_audit = models.IntegerField("是否审计")
    remark = models.TextField("备注", null=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'express'
        verbose_name = '业绩快报'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,end_date,revenue,operate_profit,total_profit,n_income,total_assets,' \
                    'total_hldr_eqy_exc_min_int,diluted_eps,diluted_roe,yoy_net_profit,bps,yoy_sales,yoy_op,yoy_tp,' \
                    'yoy_dedu_np,yoy_eps,yoy_roe,growth_assets,yoy_equity,growth_bps,or_last_year,op_last_year,' \
                    'tp_last_year,np_last_year,eps_last_year,open_net_assets,open_bps,perf_summary,is_audit,remark'
        ordering = ['-end_date','-ann_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()


class FinaIndicator(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=79
    获取方式 pro.fina_indicator(ts_code='600000.SH')

    500积分+

    ts_code	str	Y	TS代码
    ann_date	str	Y	公告日期
    end_date	str	Y	报告期
    eps	float	Y	基本每股收益
    dt_eps	float	Y	稀释每股收益
    total_revenue_ps	float	Y	每股营业总收入
    revenue_ps	float	Y	每股营业收入
    capital_rese_ps	float	Y	每股资本公积
    surplus_rese_ps	float	Y	每股盈余公积
    undist_profit_ps	float	Y	每股未分配利润
    extra_item	float	Y	非经常性损益
    profit_dedt	float	Y	扣除非经常性损益后的净利润
    gross_margin	float	Y	毛利
    current_ratio	float	Y	流动比率
    quick_ratio	float	Y	速动比率
    cash_ratio	float	Y	保守速动比率
    invturn_days	float	N	存货周转天数
    arturn_days	float	N	应收账款周转天数
    inv_turn	float	N	存货周转率
    ar_turn	float	Y	应收账款周转率
    ca_turn	float	Y	流动资产周转率
    fa_turn	float	Y	固定资产周转率
    assets_turn	float	Y	总资产周转率
    op_income	float	Y	经营活动净收益
    valuechange_income	float	N	价值变动净收益
    interst_income	float	N	利息费用
    daa	float	N	折旧与摊销
    ebit	float	Y	息税前利润
    ebitda	float	Y	息税折旧摊销前利润
    fcff	float	Y	企业自由现金流量
    fcfe	float	Y	股权自由现金流量
    current_exint	float	Y	无息流动负债
    noncurrent_exint	float	Y	无息非流动负债
    interestdebt	float	Y	带息债务
    netdebt	float	Y	净债务
    tangible_asset	float	Y	有形资产
    working_capital	float	Y	营运资金
    networking_capital	float	Y	营运流动资本
    invest_capital	float	Y	全部投入资本
    retained_earnings	float	Y	留存收益
    diluted2_eps	float	Y	期末摊薄每股收益
    bps	float	Y	每股净资产
    ocfps	float	Y	每股经营活动产生的现金流量净额
    retainedps	float	Y	每股留存收益
    cfps	float	Y	每股现金流量净额
    ebit_ps	float	Y	每股息税前利润
    fcff_ps	float	Y	每股企业自由现金流量
    fcfe_ps	float	Y	每股股东自由现金流量
    netprofit_margin	float	Y	销售净利率
    grossprofit_margin	float	Y	销售毛利率
    cogs_of_sales	float	Y	销售成本率
    expense_of_sales	float	Y	销售期间费用率
    profit_to_gr	float	Y	净利润/营业总收入
    saleexp_to_gr	float	Y	销售费用/营业总收入
    adminexp_of_gr	float	Y	管理费用/营业总收入
    finaexp_of_gr	float	Y	财务费用/营业总收入
    impai_ttm	float	Y	资产减值损失/营业总收入
    gc_of_gr	float	Y	营业总成本/营业总收入
    op_of_gr	float	Y	营业利润/营业总收入
    ebit_of_gr	float	Y	息税前利润/营业总收入
    roe	float	Y	净资产收益率
    roe_waa	float	Y	加权平均净资产收益率
    roe_dt	float	Y	净资产收益率(扣除非经常损益)
    roa	float	Y	总资产报酬率
    npta	float	Y	总资产净利润
    roic	float	Y	投入资本回报率
    roe_yearly	float	Y	年化净资产收益率
    roa2_yearly	float	Y	年化总资产报酬率
    roe_avg	float	N	平均净资产收益率(增发条件)
    opincome_of_ebt	float	N	经营活动净收益/利润总额
    investincome_of_ebt	float	N	价值变动净收益/利润总额
    n_op_profit_of_ebt	float	N	营业外收支净额/利润总额
    tax_to_ebt	float	N	所得税/利润总额
    dtprofit_to_profit	float	N	扣除非经常损益后的净利润/净利润
    salescash_to_or	float	N	销售商品提供劳务收到的现金/营业收入
    ocf_to_or	float	N	经营活动产生的现金流量净额/营业收入
    ocf_to_opincome	float	N	经营活动产生的现金流量净额/经营活动净收益
    capitalized_to_da	float	N	资本支出/折旧和摊销
    debt_to_assets	float	Y	资产负债率
    assets_to_eqt	float	Y	权益乘数
    dp_assets_to_eqt	float	Y	权益乘数(杜邦分析)
    ca_to_assets	float	Y	流动资产/总资产
    nca_to_assets	float	Y	非流动资产/总资产
    tbassets_to_totalassets	float	Y	有形资产/总资产
    int_to_talcap	float	Y	带息债务/全部投入资本
    eqt_to_talcapital	float	Y	归属于母公司的股东权益/全部投入资本
    currentdebt_to_debt	float	Y	流动负债/负债合计
    longdeb_to_debt	float	Y	非流动负债/负债合计
    ocf_to_shortdebt	float	Y	经营活动产生的现金流量净额/流动负债
    debt_to_eqt	float	Y	产权比率
    eqt_to_debt	float	Y	归属于母公司的股东权益/负债合计
    eqt_to_interestdebt	float	Y	归属于母公司的股东权益/带息债务
    tangibleasset_to_debt	float	Y	有形资产/负债合计
    tangasset_to_intdebt	float	Y	有形资产/带息债务
    tangibleasset_to_netdebt	float	Y	有形资产/净债务
    ocf_to_debt	float	Y	经营活动产生的现金流量净额/负债合计
    ocf_to_interestdebt	float	N	经营活动产生的现金流量净额/带息债务
    ocf_to_netdebt	float	N	经营活动产生的现金流量净额/净债务
    ebit_to_interest	float	N	已获利息倍数(EBIT/利息费用)
    longdebt_to_workingcapital	float	N	长期债务与营运资金比率
    ebitda_to_debt	float	N	息税折旧摊销前利润/负债合计
    turn_days	float	Y	营业周期
    roa_yearly	float	Y	年化总资产净利率
    roa_dp	float	Y	总资产净利率(杜邦分析)
    fixed_assets	float	Y	固定资产合计
    profit_prefin_exp	float	N	扣除财务费用前营业利润
    non_op_profit	float	N	非营业利润
    op_to_ebt	float	N	营业利润／利润总额
    nop_to_ebt	float	N	非营业利润／利润总额
    ocf_to_profit	float	N	经营活动产生的现金流量净额／营业利润
    cash_to_liqdebt	float	N	货币资金／流动负债
    cash_to_liqdebt_withinterest	float	N	货币资金／带息流动负债
    op_to_liqdebt	float	N	营业利润／流动负债
    op_to_debt	float	N	营业利润／负债合计
    roic_yearly	float	N	年化投入资本回报率
    total_fa_trun	float	N	固定资产合计周转率
    profit_to_op	float	Y	利润总额／营业收入
    q_opincome	float	N	经营活动单季度净收益
    q_investincome	float	N	价值变动单季度净收益
    q_dtprofit	float	N	扣除非经常损益后的单季度净利润
    q_eps	float	N	每股收益(单季度)
    q_netprofit_margin	float	N	销售净利率(单季度)
    q_gsprofit_margin	float	N	销售毛利率(单季度)
    q_exp_to_sales	float	N	销售期间费用率(单季度)
    q_profit_to_gr	float	N	净利润／营业总收入(单季度)
    q_saleexp_to_gr	float	Y	销售费用／营业总收入 (单季度)
    q_adminexp_to_gr	float	N	管理费用／营业总收入 (单季度)
    q_finaexp_to_gr	float	N	财务费用／营业总收入 (单季度)
    q_impair_to_gr_ttm	float	N	资产减值损失／营业总收入(单季度)
    q_gc_to_gr	float	Y	营业总成本／营业总收入 (单季度)
    q_op_to_gr	float	N	营业利润／营业总收入(单季度)
    q_roe	float	Y	净资产收益率(单季度)
    q_dt_roe	float	Y	净资产单季度收益率(扣除非经常损益)
    q_npta	float	Y	总资产净利润(单季度)
    q_opincome_to_ebt	float	N	经营活动净收益／利润总额(单季度)
    q_investincome_to_ebt	float	N	价值变动净收益／利润总额(单季度)
    q_dtprofit_to_profit	float	N	扣除非经常损益后的净利润／净利润(单季度)
    q_salescash_to_or	float	N	销售商品提供劳务收到的现金／营业收入(单季度)
    q_ocf_to_sales	float	Y	经营活动产生的现金流量净额／营业收入(单季度)
    q_ocf_to_or	float	N	经营活动产生的现金流量净额／经营活动净收益(单季度)
    basic_eps_yoy	float	Y	基本每股收益同比增长率(%)
    dt_eps_yoy	float	Y	稀释每股收益同比增长率(%)
    cfps_yoy	float	Y	每股经营活动产生的现金流量净额同比增长率(%)
    op_yoy	float	Y	营业利润同比增长率(%)
    ebt_yoy	float	Y	利润总额同比增长率(%)
    netprofit_yoy	float	Y	归属母公司股东的净利润同比增长率(%)
    dt_netprofit_yoy	float	Y	归属母公司股东的净利润-扣除非经常损益同比增长率(%)
    ocf_yoy	float	Y	经营活动产生的现金流量净额同比增长率(%)
    roe_yoy	float	Y	净资产收益率(摊薄)同比增长率(%)
    bps_yoy	float	Y	每股净资产相对年初增长率(%)
    assets_yoy	float	Y	资产总计相对年初增长率(%)
    eqt_yoy	float	Y	归属母公司的股东权益相对年初增长率(%)
    tr_yoy	float	Y	营业总收入同比增长率(%)
    or_yoy	float	Y	营业收入同比增长率(%)
    q_gr_yoy	float	N	营业总收入同比增长率(%)(单季度)
    q_gr_qoq	float	N	营业总收入环比增长率(%)(单季度)
    q_sales_yoy	float	Y	营业收入同比增长率(%)(单季度)
    q_sales_qoq	float	N	营业收入环比增长率(%)(单季度)
    q_op_yoy	float	N	营业利润同比增长率(%)(单季度)
    q_op_qoq	float	Y	营业利润环比增长率(%)(单季度)
    q_profit_yoy	float	N	净利润同比增长率(%)(单季度)
    q_profit_qoq	float	N	净利润环比增长率(%)(单季度)
    q_netprofit_yoy	float	N	归属母公司股东的净利润同比增长率(%)(单季度)
    q_netprofit_qoq	float	N	归属母公司股东的净利润环比增长率(%)(单季度)
    equity_yoy	float	Y	净资产同比增长率
    rd_exp	float	N	研发费用
    update_flag	str	N	更新标识

    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    ann_date = models.IntegerField("公告日期", db_index=True)
    end_date = models.IntegerField("报告期", db_index=True)
    eps = models.DecimalField(max_digits=18, decimal_places=4,  null=True, verbose_name="基本每股收益")
    dt_eps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="稀释每股收益")
    total_revenue_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股营业总收入")
    revenue_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股营业收入")
    capital_rese_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股资本公积")
    surplus_rese_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股盈余公积")
    undist_profit_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股未分配利润")
    extra_item = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="非经常性损益")
    profit_dedt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="扣除非经常性损益后的净利润")
    gross_margin = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="毛利")
    current_ratio = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="流动比率")
    quick_ratio = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="速动比率")
    cash_ratio = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="保守速动比率")
    invturn_days = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="存货周转天数")
    arturn_days = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="应收账款周转天数")
    inv_turn = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="存货周转率")
    ar_turn = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="应收账款周转率")
    ca_turn = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="流动资产周转率")
    fa_turn = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="固定资产周转率")
    assets_turn = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="总资产周转率")
    op_income = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动净收益")
    valuechange_income = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="价值变动净收益")
    interst_income = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="利息费用")
    daa = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="折旧与摊销")
    ebit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="息税前利润")
    ebitda = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="息税折旧摊销前利润")
    fcff = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="企业自由现金流量")
    fcfe = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="股权自由现金流量")
    current_exint = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="无息流动负债")
    noncurrent_exint = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="无息非流动负债")
    interestdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="带息债务")
    netdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净债务")
    tangible_asset = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="有形资产")
    working_capital = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营运资金")
    networking_capital = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营运流动资本")
    invest_capital = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="全部投入资本")
    retained_earnings = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="留存收益")
    diluted2_eps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="期末摊薄每股收益")
    bps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股净资产")
    ocfps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股经营活动产生的现金流量净额")
    retainedps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股留存收益")
    cfps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股现金流量净额")
    ebit_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股息税前利润")
    fcff_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股企业自由现金流量")
    fcfe_ps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股股东自由现金流量")
    netprofit_margin = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售净利率")
    grossprofit_margin = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售毛利率")
    cogs_of_sales = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售成本率")
    expense_of_sales = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售期间费用率")
    profit_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净利润/营业总收入")
    saleexp_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售费用/营业总收入")
    adminexp_of_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="管理费用/营业总收入")
    finaexp_of_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="财务费用/营业总收入")
    impai_ttm = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="资产减值损失/营业总收入")
    gc_of_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业总成本/营业总收入")
    op_of_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润/营业总收入")
    ebit_of_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="息税前利润/营业总收入")
    roe = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产收益率")
    roe_waa = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="加权平均净资产收益率")
    roe_dt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产收益率(扣除非经常损益)")
    roa = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="总资产报酬率")
    npta = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="总资产净利润")
    roic = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="投入资本回报率")
    roe_yearly = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="年化净资产收益率")
    roa2_yearly = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="年化总资产报酬率")
    roe_avg = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="平均净资产收益率(增发条件)")
    opincome_of_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动净收益/利润总额")
    investincome_of_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="价值变动净收益/利润总额")
    n_op_profit_of_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业外收支净额/利润总额")
    tax_to_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="所得税/利润总额")
    dtprofit_to_profit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="扣除非经常损益后的净利润/净利润")
    salescash_to_or = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售商品提供劳务收到的现金/营业收入")
    ocf_to_or = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/营业收入")
    ocf_to_opincome = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/经营活动净收益")
    capitalized_to_da = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="资本支出/折旧和摊销")
    debt_to_assets = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="资产负债率")
    assets_to_eqt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="权益乘数")
    dp_assets_to_eqt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="权益乘数(杜邦分析)")
    ca_to_assets = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="流动资产/总资产")
    nca_to_assets = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="非流动资产/总资产")
    tbassets_to_totalassets = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="有形资产/总资产")
    int_to_talcap = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="带息债务/全部投入资本")
    eqt_to_talcapital = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属于母公司的股东权益/全部投入资本")
    currentdebt_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="流动负债/负债合计")
    longdeb_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="非流动负债/负债合计")
    ocf_to_shortdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/流动负债")
    debt_to_eqt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="产权比率")
    eqt_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属于母公司的股东权益/负债合计")
    eqt_to_interestdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属于母公司的股东权益/带息债务")
    tangibleasset_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="有形资产/负债合计")
    tangasset_to_intdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="有形资产/带息债务")
    tangibleasset_to_netdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="有形资产/净债务")
    ocf_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/负债合计")
    ocf_to_interestdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/带息债务")
    ocf_to_netdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额/净债务")
    ebit_to_interest = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="已获利息倍数(EBIT/利息费用)")
    longdebt_to_workingcapital = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="长期债务与营运资金比率")
    ebitda_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="息税折旧摊销前利润/负债合计")
    turn_days = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业周期")
    roa_yearly = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="年化总资产净利率")
    roa_dp = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="总资产净利率(杜邦分析)")
    fixed_assets = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="固定资产合计")
    profit_prefin_exp = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="扣除财务费用前营业利润")
    non_op_profit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="非营业利润")
    op_to_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润／利润总额")
    nop_to_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="非营业利润／利润总额")
    ocf_to_profit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额／营业利润")
    cash_to_liqdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="货币资金／流动负债")
    cash_to_liqdebt_withinterest = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="货币资金／带息流动负债")
    op_to_liqdebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润／流动负债")
    op_to_debt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润／负债合计")
    roic_yearly = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="年化投入资本回报率")
    total_fa_trun = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="固定资产合计周转率")
    profit_to_op = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="利润总额／营业收入")
    q_opincome = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动单季度净收益")
    q_investincome = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="价值变动单季度净收益")
    q_dtprofit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="扣除非经常损益后的单季度净利润")
    q_eps = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股收益(单季度)")
    q_netprofit_margin = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售净利率(单季度)")
    q_gsprofit_margin = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售毛利率(单季度)")
    q_exp_to_sales = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售期间费用率(单季度)")
    q_profit_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净利润／营业总收入(单季度)")
    q_saleexp_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售费用／营业总收入 (单季度)")
    q_adminexp_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="管理费用／营业总收入 (单季度)")
    q_finaexp_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="财务费用／营业总收入 (单季度)")
    q_impair_to_gr_ttm = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="资产减值损失／营业总收入(单季度)")
    q_gc_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业总成本／营业总收入 (单季度)")
    q_op_to_gr = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润／营业总收入(单季度)")
    q_roe = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产收益率(单季度)")
    q_dt_roe = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产单季度收益率(扣除非经常损益)")
    q_npta = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="总资产净利润(单季度)")
    q_opincome_to_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动净收益／利润总额(单季度)")
    q_investincome_to_ebt = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="价值变动净收益／利润总额(单季度)")
    q_dtprofit_to_profit = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="扣除非经常损益后的净利润／净利润(单季度)")
    q_salescash_to_or = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="销售商品提供劳务收到的现金／营业收入(单季度)")
    q_ocf_to_sales = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额／营业收入(单季度)")
    q_ocf_to_or = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额／经营活动净收益(单季度)")
    basic_eps_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="基本每股收益同比增长率(%)")
    dt_eps_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="稀释每股收益同比增长率(%)")
    cfps_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股经营活动产生的现金流量净额同比增长率(%)")
    op_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润同比增长率(%)")
    ebt_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="利润总额同比增长率(%)")
    netprofit_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属母公司股东的净利润同比增长率(%)")
    dt_netprofit_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属母公司股东的净利润-扣除非经常损益同比增长率(%)")
    ocf_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="经营活动产生的现金流量净额同比增长率(%)")
    roe_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产收益率(摊薄)同比增长率(%)")
    bps_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="每股净资产相对年初增长率(%)")
    assets_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="资产总计相对年初增长率(%)")
    eqt_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属母公司的股东权益相对年初增长率(%)")
    tr_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业总收入同比增长率(%)")
    or_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业收入同比增长率(%)")
    q_gr_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业总收入同比增长率(%)(单季度)")
    q_gr_qoq = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业总收入环比增长率(%)(单季度)")
    q_sales_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业收入同比增长率(%)(单季度)")
    q_sales_qoq = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业收入环比增长率(%)(单季度)")
    q_op_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润同比增长率(%)(单季度)")
    q_op_qoq = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="营业利润环比增长率(%)(单季度)")
    q_profit_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净利润同比增长率(%)(单季度)")
    q_profit_qoq = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净利润环比增长率(%)(单季度)")
    q_netprofit_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属母公司股东的净利润同比增长率(%)(单季度)")
    q_netprofit_qoq = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="归属母公司股东的净利润环比增长率(%)(单季度)")
    equity_yoy = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="净资产同比增长率")
    rd_exp = models.DecimalField(max_digits=18, decimal_places=4, null=True, verbose_name="研发费用")
    update_flag = models.IntegerField("更新标识")
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'finaindicator'
        verbose_name = '财务指标数据'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,end_date,eps,dt_eps,total_revenue_ps,revenue_ps,capital_rese_ps,surplus_rese_ps,' \
                    'undist_profit_ps,extra_item,profit_dedt,gross_margin,current_ratio,quick_ratio,cash_ratio,' \
                    'invturn_days,arturn_days,inv_turn,ar_turn,ca_turn,fa_turn,assets_turn,op_income,' \
                    'valuechange_income,interst_income,daa,ebit,ebitda,fcff,fcfe,current_exint,noncurrent_exint,' \
                    'interestdebt,netdebt,tangible_asset,working_capital,networking_capital,invest_capital,' \
                    'retained_earnings,diluted2_eps,bps,ocfps,retainedps,cfps,ebit_ps,fcff_ps,fcfe_ps,' \
                    'netprofit_margin,grossprofit_margin,cogs_of_sales,expense_of_sales,profit_to_gr,saleexp_to_gr,' \
                    'adminexp_of_gr,finaexp_of_gr,impai_ttm,gc_of_gr,op_of_gr,ebit_of_gr,roe,roe_waa,roe_dt,roa,npta,' \
                    'roic,roe_yearly,roa2_yearly,roe_avg,opincome_of_ebt,investincome_of_ebt,n_op_profit_of_ebt,' \
                    'tax_to_ebt,dtprofit_to_profit,salescash_to_or,ocf_to_or,ocf_to_opincome,capitalized_to_da,' \
                    'debt_to_assets,assets_to_eqt,dp_assets_to_eqt,ca_to_assets,nca_to_assets,' \
                    'tbassets_to_totalassets,int_to_talcap,eqt_to_talcapital,currentdebt_to_debt,longdeb_to_debt,' \
                    'ocf_to_shortdebt,debt_to_eqt,eqt_to_debt,eqt_to_interestdebt,tangibleasset_to_debt,' \
                    'tangasset_to_intdebt,tangibleasset_to_netdebt,ocf_to_debt,ocf_to_interestdebt,ocf_to_netdebt,' \
                    'ebit_to_interest,longdebt_to_workingcapital,ebitda_to_debt,turn_days,roa_yearly,roa_dp,' \
                    'fixed_assets,profit_prefin_exp,non_op_profit,op_to_ebt,nop_to_ebt,ocf_to_profit,cash_to_liqdebt,' \
                    'cash_to_liqdebt_withinterest,op_to_liqdebt,op_to_debt,roic_yearly,total_fa_trun,profit_to_op,' \
                    'q_opincome,q_investincome,q_dtprofit,q_eps,q_netprofit_margin,q_gsprofit_margin,q_exp_to_sales,' \
                    'q_profit_to_gr,q_saleexp_to_gr,q_adminexp_to_gr,q_finaexp_to_gr,q_impair_to_gr_ttm,q_gc_to_gr,' \
                    'q_op_to_gr,q_roe,q_dt_roe,q_npta,q_opincome_to_ebt,q_investincome_to_ebt,q_dtprofit_to_profit,' \
                    'q_salescash_to_or,q_ocf_to_sales,q_ocf_to_or,basic_eps_yoy,dt_eps_yoy,cfps_yoy,op_yoy,ebt_yoy,' \
                    'netprofit_yoy,dt_netprofit_yoy,ocf_yoy,roe_yoy,bps_yoy,assets_yoy,eqt_yoy,tr_yoy,or_yoy,' \
                    'q_gr_yoy,q_gr_qoq,q_sales_yoy,q_sales_qoq,q_op_yoy,q_op_qoq,q_profit_yoy,q_profit_qoq,' \
                    'q_netprofit_yoy,q_netprofit_qoq,equity_yoy,rd_exp,update_flag'
        ordering = ['-end_date','-ann_date', 'ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()


class BalanceSheet(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=36
    获取方式 pro.balancesheet(ts_code='600000.SH'， fields="")

    ts_code	str	Y	TS股票代码
    ann_date	str	Y	公告日期
    f_ann_date	str	Y	实际公告日期
    end_date	str	Y	报告期
    report_type	str	Y	报表类型
    comp_type	str	Y	公司类型
    total_share	float	Y	期末总股本
    cap_rese	float	Y	资本公积金
    undistr_porfit	float	Y	未分配利润
    surplus_rese	float	Y	盈余公积金
    special_rese	float	Y	专项储备
    money_cap	float	Y	货币资金
    trad_asset	float	Y	交易性金融资产
    notes_receiv	float	Y	应收票据
    accounts_receiv	float	Y	应收账款
    oth_receiv	float	Y	其他应收款
    prepayment	float	Y	预付款项
    div_receiv	float	Y	应收股利
    int_receiv	float	Y	应收利息
    inventories	float	Y	存货
    amor_exp	float	Y	长期待摊费用
    nca_within_1y	float	Y	一年内到期的非流动资产
    sett_rsrv	float	Y	结算备付金
    loanto_oth_bank_fi	float	Y	拆出资金
    premium_receiv	float	Y	应收保费
    reinsur_receiv	float	Y	应收分保账款
    reinsur_res_receiv	float	Y	应收分保合同准备金
    pur_resale_fa	float	Y	买入返售金融资产
    oth_cur_assets	float	Y	其他流动资产
    total_cur_assets	float	Y	流动资产合计
    fa_avail_for_sale	float	Y	可供出售金融资产
    htm_invest	float	Y	持有至到期投资
    lt_eqt_invest	float	Y	长期股权投资
    invest_real_estate	float	Y	投资性房地产
    time_deposits	float	Y	定期存款
    oth_assets	float	Y	其他资产
    lt_rec	float	Y	长期应收款
    fix_assets	float	Y	固定资产
    cip	float	Y	在建工程
    const_materials	float	Y	工程物资
    fixed_assets_disp	float	Y	固定资产清理
    produc_bio_assets	float	Y	生产性生物资产
    oil_and_gas_assets	float	Y	油气资产
    intan_assets	float	Y	无形资产
    r_and_d	float	Y	研发支出
    goodwill	float	Y	商誉
    lt_amor_exp	float	Y	长期待摊费用
    defer_tax_assets	float	Y	递延所得税资产
    decr_in_disbur	float	Y	发放贷款及垫款
    oth_nca	float	Y	其他非流动资产
    total_nca	float	Y	非流动资产合计
    cash_reser_cb	float	Y	现金及存放中央银行款项
    depos_in_oth_bfi	float	Y	存放同业和其它金融机构款项
    prec_metals	float	Y	贵金属
    deriv_assets	float	Y	衍生金融资产
    rr_reins_une_prem	float	Y	应收分保未到期责任准备金
    rr_reins_outstd_cla	float	Y	应收分保未决赔款准备金
    rr_reins_lins_liab	float	Y	应收分保寿险责任准备金
    rr_reins_lthins_liab	float	Y	应收分保长期健康险责任准备金
    refund_depos	float	Y	存出保证金
    ph_pledge_loans	float	Y	保户质押贷款
    refund_cap_depos	float	Y	存出资本保证金
    indep_acct_assets	float	Y	独立账户资产
    client_depos	float	Y	其中：客户资金存款
    client_prov	float	Y	其中：客户备付金
    transac_seat_fee	float	Y	其中:交易席位费
    invest_as_receiv	float	Y	应收款项类投资
    total_assets	float	Y	资产总计
    lt_borr	float	Y	长期借款
    st_borr	float	Y	短期借款
    cb_borr	float	Y	向中央银行借款
    depos_ib_deposits	float	Y	吸收存款及同业存放
    loan_oth_bank	float	Y	拆入资金
    trading_fl	float	Y	交易性金融负债
    notes_payable	float	Y	应付票据
    acct_payable	float	Y	应付账款
    adv_receipts	float	Y	预收款项
    sold_for_repur_fa	float	Y	卖出回购金融资产款
    comm_payable	float	Y	应付手续费及佣金
    payroll_payable	float	Y	应付职工薪酬
    taxes_payable	float	Y	应交税费
    int_payable	float	Y	应付利息
    div_payable	float	Y	应付股利
    oth_payable	float	Y	其他应付款
    acc_exp	float	Y	预提费用
    deferred_inc	float	Y	递延收益
    st_bonds_payable	float	Y	应付短期债券
    payable_to_reinsurer	float	Y	应付分保账款
    rsrv_insur_cont	float	Y	保险合同准备金
    acting_trading_sec	float	Y	代理买卖证券款
    acting_uw_sec	float	Y	代理承销证券款
    non_cur_liab_due_1y	float	Y	一年内到期的非流动负债
    oth_cur_liab	float	Y	其他流动负债
    total_cur_liab	float	Y	流动负债合计
    bond_payable	float	Y	应付债券
    lt_payable	float	Y	长期应付款
    specific_payables	float	Y	专项应付款
    estimated_liab	float	Y	预计负债
    defer_tax_liab	float	Y	递延所得税负债
    defer_inc_non_cur_liab	float	Y	递延收益-非流动负债
    oth_ncl	float	Y	其他非流动负债
    total_ncl	float	Y	非流动负债合计
    depos_oth_bfi	float	Y	同业和其它金融机构存放款项
    deriv_liab	float	Y	衍生金融负债
    depos	float	Y	吸收存款
    agency_bus_liab	float	Y	代理业务负债
    oth_liab	float	Y	其他负债
    prem_receiv_adva	float	Y	预收保费
    depos_received	float	Y	存入保证金
    ph_invest	float	Y	保户储金及投资款
    reser_une_prem	float	Y	未到期责任准备金
    reser_outstd_claims	float	Y	未决赔款准备金
    reser_lins_liab	float	Y	寿险责任准备金
    reser_lthins_liab	float	Y	长期健康险责任准备金
    indept_acc_liab	float	Y	独立账户负债
    pledge_borr	float	Y	其中:质押借款
    indem_payable	float	Y	应付赔付款
    policy_div_payable	float	Y	应付保单红利
    total_liab	float	Y	负债合计
    treasury_share	float	Y	减:库存股
    ordin_risk_reser	float	Y	一般风险准备
    forex_differ	float	Y	外币报表折算差额
    invest_loss_unconf	float	Y	未确认的投资损失
    minority_int	float	Y	少数股东权益
    total_hldr_eqy_exc_min_int	float	Y	股东权益合计(不含少数股东权益)
    total_hldr_eqy_inc_min_int	float	Y	股东权益合计(含少数股东权益)
    total_liab_hldr_eqy	float	Y	负债及股东权益总计
    lt_payroll_payable	float	Y	长期应付职工薪酬
    oth_comp_income	float	Y	其他综合收益
    oth_eqt_tools	float	Y	其他权益工具
    oth_eqt_tools_p_shr	float	Y	其他权益工具(优先股)
    lending_funds	float	Y	融出资金
    acc_receivable	float	Y	应收款项
    st_fin_payable	float	Y	应付短期融资款
    payables	float	Y	应付款项
    hfs_assets	float	Y	持有待售的资产
    hfs_sales	float	Y	持有待售的负债

    """

    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    ann_date = models.IntegerField("公告日期", db_index=True, null=True)
    f_ann_date = models.IntegerField("实际公告日期", db_index=True, null=True)
    end_date = models.IntegerField("报告期", db_index=True, null=True)
    report_type = models.IntegerField("报告类型", db_index=True, null=True, choices=choice.income_report_type)
    comp_type = models.IntegerField("公司类型", db_index=True, null=True, choices=choice.income_comp_type)
    total_share = models.DecimalField("期末总股本", max_digits=18, decimal_places=4, null=True)
    cap_rese = models.DecimalField("资本公积金", max_digits=18, decimal_places=4, null=True)
    undistr_porfit = models.DecimalField("未分配利润", max_digits=18, decimal_places=4, null=True)
    surplus_rese = models.DecimalField("盈余公积金", max_digits=18, decimal_places=4, null=True)
    special_rese = models.DecimalField("专项储备", max_digits=18, decimal_places=4, null=True)
    money_cap = models.DecimalField("货币资金", max_digits=18, decimal_places=4, null=True)
    trad_asset = models.DecimalField("交易性金融资产", max_digits=18, decimal_places=4, null=True)
    notes_receiv = models.DecimalField("应收票据", max_digits=18, decimal_places=4, null=True)
    accounts_receiv = models.DecimalField("应收账款", max_digits=18, decimal_places=4, null=True)
    oth_receiv = models.DecimalField("其他应收款", max_digits=18, decimal_places=4, null=True)
    prepayment = models.DecimalField("预付款项", max_digits=18, decimal_places=4, null=True)
    div_receiv = models.DecimalField("应收股利", max_digits=18, decimal_places=4, null=True)
    int_receiv = models.DecimalField("应收利息", max_digits=18, decimal_places=4, null=True)
    inventories = models.DecimalField("存货", max_digits=18, decimal_places=4, null=True)
    amor_exp = models.DecimalField("长期待摊费用", max_digits=18, decimal_places=4, null=True)
    nca_within_1y = models.DecimalField("一年内到期的非流动资产", max_digits=18, decimal_places=4, null=True)
    sett_rsrv = models.DecimalField("结算备付金", max_digits=18, decimal_places=4, null=True)
    loanto_oth_bank_fi = models.DecimalField("拆出资金", max_digits=18, decimal_places=4, null=True)
    premium_receiv = models.DecimalField("应收保费", max_digits=18, decimal_places=4, null=True)
    reinsur_receiv = models.DecimalField("应收分保账款", max_digits=18, decimal_places=4, null=True)
    reinsur_res_receiv = models.DecimalField("应收分保合同准备金", max_digits=18, decimal_places=4, null=True)
    pur_resale_fa = models.DecimalField("买入返售金融资产", max_digits=18, decimal_places=4, null=True)
    oth_cur_assets = models.DecimalField("其他流动资产", max_digits=18, decimal_places=4, null=True)
    total_cur_assets = models.DecimalField("流动资产合计", max_digits=18, decimal_places=4, null=True)
    fa_avail_for_sale = models.DecimalField("可供出售金融资产", max_digits=18, decimal_places=4, null=True)
    htm_invest = models.DecimalField("持有至到期投资", max_digits=18, decimal_places=4, null=True)
    lt_eqt_invest = models.DecimalField("长期股权投资", max_digits=18, decimal_places=4, null=True)
    invest_real_estate = models.DecimalField("投资性房地产", max_digits=18, decimal_places=4, null=True)
    time_deposits = models.DecimalField("定期存款", max_digits=18, decimal_places=4, null=True)
    oth_assets = models.DecimalField("其他资产", max_digits=18, decimal_places=4, null=True)
    lt_rec = models.DecimalField("长期应收款", max_digits=18, decimal_places=4, null=True)
    fix_assets = models.DecimalField("固定资产", max_digits=18, decimal_places=4, null=True)
    cip = models.DecimalField("在建工程", max_digits=18, decimal_places=4, null=True)
    const_materials = models.DecimalField("工程物资", max_digits=18, decimal_places=4, null=True)
    fixed_assets_disp = models.DecimalField("固定资产清理", max_digits=18, decimal_places=4, null=True)
    produc_bio_assets = models.DecimalField("生产性生物资产", max_digits=18, decimal_places=4, null=True)
    oil_and_gas_assets = models.DecimalField("油气资产", max_digits=18, decimal_places=4, null=True)
    intan_assets = models.DecimalField("无形资产", max_digits=18, decimal_places=4, null=True)
    r_and_d = models.DecimalField("研发支出", max_digits=18, decimal_places=4, null=True)
    goodwill = models.DecimalField("商誉", max_digits=18, decimal_places=4, null=True)
    lt_amor_exp = models.DecimalField("长期待摊费用", max_digits=18, decimal_places=4, null=True)
    defer_tax_assets = models.DecimalField("递延所得税资产", max_digits=18, decimal_places=4, null=True)
    decr_in_disbur = models.DecimalField("发放贷款及垫款", max_digits=18, decimal_places=4, null=True)
    oth_nca = models.DecimalField("其他非流动资产", max_digits=18, decimal_places=4, null=True)
    total_nca = models.DecimalField("非流动资产合计", max_digits=18, decimal_places=4, null=True)
    cash_reser_cb = models.DecimalField("现金及存放中央银行款项", max_digits=18, decimal_places=4, null=True)
    depos_in_oth_bfi = models.DecimalField("存放同业和其它金融机构款项", max_digits=18, decimal_places=4, null=True)
    prec_metals = models.DecimalField("贵金属", max_digits=18, decimal_places=4, null=True)
    deriv_assets = models.DecimalField("衍生金融资产", max_digits=18, decimal_places=4, null=True)
    rr_reins_une_prem = models.DecimalField("应收分保未到期责任准备金", max_digits=18, decimal_places=4, null=True)
    rr_reins_outstd_cla = models.DecimalField("应收分保未决赔款准备金", max_digits=18, decimal_places=4, null=True)
    rr_reins_lins_liab = models.DecimalField("应收分保寿险责任准备金", max_digits=18, decimal_places=4, null=True)
    rr_reins_lthins_liab = models.DecimalField("应收分保长期健康险责任准备金", max_digits=18, decimal_places=4, null=True)
    refund_depos = models.DecimalField("存出保证金", max_digits=18, decimal_places=4, null=True)
    ph_pledge_loans = models.DecimalField("保户质押贷款", max_digits=18, decimal_places=4, null=True)
    refund_cap_depos = models.DecimalField("存出资本保证金", max_digits=18, decimal_places=4, null=True)
    indep_acct_assets = models.DecimalField("独立账户资产", max_digits=18, decimal_places=4, null=True)
    client_depos = models.DecimalField("其中：客户资金存款", max_digits=18, decimal_places=4, null=True)
    client_prov = models.DecimalField("其中：客户备付金", max_digits=18, decimal_places=4, null=True)
    transac_seat_fee = models.DecimalField("其中:交易席位费", max_digits=18, decimal_places=4, null=True)
    invest_as_receiv = models.DecimalField("应收款项类投资", max_digits=18, decimal_places=4, null=True)
    total_assets = models.DecimalField("资产总计", max_digits=18, decimal_places=4, null=True)
    lt_borr = models.DecimalField("长期借款", max_digits=18, decimal_places=4, null=True)
    st_borr = models.DecimalField("短期借款", max_digits=18, decimal_places=4, null=True)
    cb_borr = models.DecimalField("向中央银行借款", max_digits=18, decimal_places=4, null=True)
    depos_ib_deposits = models.DecimalField("吸收存款及同业存放", max_digits=18, decimal_places=4, null=True)
    loan_oth_bank = models.DecimalField("拆入资金", max_digits=18, decimal_places=4, null=True)
    trading_fl = models.DecimalField("交易性金融负债", max_digits=18, decimal_places=4, null=True)
    notes_payable = models.DecimalField("应付票据", max_digits=18, decimal_places=4, null=True)
    acct_payable = models.DecimalField("应付账款", max_digits=18, decimal_places=4, null=True)
    adv_receipts = models.DecimalField("预收款项", max_digits=18, decimal_places=4, null=True)
    sold_for_repur_fa = models.DecimalField("卖出回购金融资产款", max_digits=18, decimal_places=4, null=True)
    comm_payable = models.DecimalField("应付手续费及佣金", max_digits=18, decimal_places=4, null=True)
    payroll_payable = models.DecimalField("应付职工薪酬", max_digits=18, decimal_places=4, null=True)
    taxes_payable = models.DecimalField("应交税费", max_digits=18, decimal_places=4, null=True)
    int_payable = models.DecimalField("应付利息", max_digits=18, decimal_places=4, null=True)
    div_payable = models.DecimalField("应付股利", max_digits=18, decimal_places=4, null=True)
    oth_payable = models.DecimalField("其他应付款", max_digits=18, decimal_places=4, null=True)
    acc_exp = models.DecimalField("预提费用", max_digits=18, decimal_places=4, null=True)
    deferred_inc = models.DecimalField("递延收益", max_digits=18, decimal_places=4, null=True)
    st_bonds_payable = models.DecimalField("应付短期债券", max_digits=18, decimal_places=4, null=True)
    payable_to_reinsurer = models.DecimalField("应付分保账款", max_digits=18, decimal_places=4, null=True)
    rsrv_insur_cont = models.DecimalField("保险合同准备金", max_digits=18, decimal_places=4, null=True)
    acting_trading_sec = models.DecimalField("代理买卖证券款", max_digits=18, decimal_places=4, null=True)
    acting_uw_sec = models.DecimalField("代理承销证券款", max_digits=18, decimal_places=4, null=True)
    non_cur_liab_due_1y = models.DecimalField("一年内到期的非流动负债", max_digits=18, decimal_places=4, null=True)
    oth_cur_liab = models.DecimalField("其他流动负债", max_digits=18, decimal_places=4, null=True)
    total_cur_liab = models.DecimalField("流动负债合计", max_digits=18, decimal_places=4, null=True)
    bond_payable = models.DecimalField("应付债券", max_digits=18, decimal_places=4, null=True)
    lt_payable = models.DecimalField("长期应付款", max_digits=18, decimal_places=4, null=True)
    specific_payables = models.DecimalField("专项应付款", max_digits=18, decimal_places=4, null=True)
    estimated_liab = models.DecimalField("预计负债", max_digits=18, decimal_places=4, null=True)
    defer_tax_liab = models.DecimalField("递延所得税负债", max_digits=18, decimal_places=4, null=True)
    defer_inc_non_cur_liab = models.DecimalField("递延收益-非流动负债", max_digits=18, decimal_places=4, null=True)
    oth_ncl = models.DecimalField("其他非流动负债", max_digits=18, decimal_places=4, null=True)
    total_ncl = models.DecimalField("非流动负债合计", max_digits=18, decimal_places=4, null=True)
    depos_oth_bfi = models.DecimalField("同业和其它金融机构存放款项", max_digits=18, decimal_places=4, null=True)
    deriv_liab = models.DecimalField("衍生金融负债", max_digits=18, decimal_places=4, null=True)
    depos = models.DecimalField("吸收存款", max_digits=18, decimal_places=4, null=True)
    agency_bus_liab = models.DecimalField("代理业务负债", max_digits=18, decimal_places=4, null=True)
    oth_liab = models.DecimalField("其他负债", max_digits=18, decimal_places=4, null=True)
    prem_receiv_adva = models.DecimalField("预收保费", max_digits=18, decimal_places=4, null=True)
    depos_received = models.DecimalField("存入保证金", max_digits=18, decimal_places=4, null=True)
    ph_invest = models.DecimalField("保户储金及投资款", max_digits=18, decimal_places=4, null=True)
    reser_une_prem = models.DecimalField("未到期责任准备金", max_digits=18, decimal_places=4, null=True)
    reser_outstd_claims = models.DecimalField("未决赔款准备金", max_digits=18, decimal_places=4, null=True)
    reser_lins_liab = models.DecimalField("寿险责任准备金", max_digits=18, decimal_places=4, null=True)
    reser_lthins_liab = models.DecimalField("长期健康险责任准备金", max_digits=18, decimal_places=4, null=True)
    indept_acc_liab = models.DecimalField("独立账户负债", max_digits=18, decimal_places=4, null=True)
    pledge_borr = models.DecimalField("其中:质押借款", max_digits=18, decimal_places=4, null=True)
    indem_payable = models.DecimalField("应付赔付款", max_digits=18, decimal_places=4, null=True)
    policy_div_payable = models.DecimalField("应付保单红利", max_digits=18, decimal_places=4, null=True)
    total_liab = models.DecimalField("负债合计", max_digits=18, decimal_places=4, null=True)
    treasury_share = models.DecimalField("减:库存股", max_digits=18, decimal_places=4, null=True)
    ordin_risk_reser = models.DecimalField("一般风险准备", max_digits=18, decimal_places=4, null=True)
    forex_differ = models.DecimalField("外币报表折算差额", max_digits=18, decimal_places=4, null=True)
    invest_loss_unconf = models.DecimalField("未确认的投资损失", max_digits=18, decimal_places=4, null=True)
    minority_int = models.DecimalField("少数股东权益", max_digits=18, decimal_places=4, null=True)
    total_hldr_eqy_exc_min_int = models.DecimalField("股东权益合计(不含少数股东权益)", max_digits=18, decimal_places=4, null=True)
    total_hldr_eqy_inc_min_int = models.DecimalField("股东权益合计(含少数股东权益)", max_digits=18, decimal_places=4, null=True)
    total_liab_hldr_eqy = models.DecimalField("负债及股东权益总计", max_digits=18, decimal_places=4, null=True)
    lt_payroll_payable = models.DecimalField("长期应付职工薪酬", max_digits=18, decimal_places=4, null=True)
    oth_comp_income = models.DecimalField("其他综合收益", max_digits=18, decimal_places=4, null=True)
    oth_eqt_tools = models.DecimalField("其他权益工具", max_digits=18, decimal_places=4, null=True)
    oth_eqt_tools_p_shr = models.DecimalField("其他权益工具(优先股)", max_digits=18, decimal_places=4, null=True)
    lending_funds = models.DecimalField("融出资金", max_digits=18, decimal_places=4, null=True)
    acc_receivable = models.DecimalField("应收款项", max_digits=18, decimal_places=4, null=True)
    st_fin_payable = models.DecimalField("应付短期融资款", max_digits=18, decimal_places=4, null=True)
    payables = models.DecimalField("应付款项", max_digits=18, decimal_places=4, null=True)
    hfs_assets = models.DecimalField("持有待售的资产", max_digits=18, decimal_places=4, null=True)
    hfs_sales = models.DecimalField("持有待售的负债", max_digits=18, decimal_places=4, null=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'balancesheet'
        verbose_name = '资产负债表'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,f_ann_date,end_date,report_type,comp_type,total_share,cap_rese,undistr_porfit,' \
                    'surplus_rese,special_rese,money_cap,trad_asset,notes_receiv,accounts_receiv,oth_receiv,prepayment,' \
                    'div_receiv,int_receiv,inventories,amor_exp,nca_within_1y,sett_rsrv,loanto_oth_bank_fi,' \
                    'premium_receiv,reinsur_receiv,reinsur_res_receiv,pur_resale_fa,oth_cur_assets,total_cur_assets,' \
                    'fa_avail_for_sale,htm_invest,lt_eqt_invest,invest_real_estate,time_deposits,oth_assets,lt_rec,' \
                    'fix_assets,cip,const_materials,fixed_assets_disp,produc_bio_assets,oil_and_gas_assets,' \
                    'intan_assets,r_and_d,goodwill,lt_amor_exp,defer_tax_assets,decr_in_disbur,oth_nca,total_nca,' \
                    'cash_reser_cb,depos_in_oth_bfi,prec_metals,deriv_assets,rr_reins_une_prem,rr_reins_outstd_cla,' \
                    'rr_reins_lins_liab,rr_reins_lthins_liab,refund_depos,ph_pledge_loans,refund_cap_depos,' \
                    'indep_acct_assets,client_depos,client_prov,transac_seat_fee,invest_as_receiv,total_assets,' \
                    'lt_borr,st_borr,cb_borr,depos_ib_deposits,loan_oth_bank,trading_fl,notes_payable,acct_payable,' \
                    'adv_receipts,sold_for_repur_fa,comm_payable,payroll_payable,taxes_payable,int_payable,' \
                    'div_payable,oth_payable,acc_exp,deferred_inc,st_bonds_payable,payable_to_reinsurer,' \
                    'rsrv_insur_cont,acting_trading_sec,acting_uw_sec,non_cur_liab_due_1y,oth_cur_liab,' \
                    'total_cur_liab,bond_payable,lt_payable,specific_payables,estimated_liab,defer_tax_liab,' \
                    'defer_inc_non_cur_liab,oth_ncl,total_ncl,depos_oth_bfi,deriv_liab,depos,agency_bus_liab,' \
                    'oth_liab,prem_receiv_adva,depos_received,ph_invest,reser_une_prem,reser_outstd_claims,' \
                    'reser_lins_liab,reser_lthins_liab,indept_acc_liab,pledge_borr,indem_payable,policy_div_payable,' \
                    'total_liab,treasury_share,ordin_risk_reser,forex_differ,invest_loss_unconf,minority_int,' \
                    'total_hldr_eqy_exc_min_int,total_hldr_eqy_inc_min_int,total_liab_hldr_eqy,lt_payroll_payable,' \
                    'oth_comp_income,oth_eqt_tools,oth_eqt_tools_p_shr,lending_funds,acc_receivable,st_fin_payable,' \
                    'payables,hfs_assets,hfs_sales'
        ordering = ['-end_date','-ann_date','ts_code']

    def __str__(self):
        type_display = self.report_type
        for c in choice.income_report_type:
            if type_display == int(c[0]):
                type_display = c[1]
        return "[%s] %s:%s:%s" % (self.__class__.__name__, self.ts_code, self.end_date, type_display)

    def __repr__(self):
        return self.__str__()


class Pledge_Stat(models.Model):
    """
    数据来源 https://tushare.pro/document/2?doc_id=110
    获取方式 pro.pledge_stat(ts_code='000014.SZ')

    """
    ts_code = models.CharField("TS代码", max_length=20, null=True, blank=False, db_index=True)
    end_date = models.IntegerField("报告期", db_index=True, null=True)
    pledge_count = models.IntegerField("质押次数", null=True, blank=False, db_index=True)
    unrest_pledge = models.DecimalField("无限售股质押数量（万）", max_digits=18, decimal_places=4, null=True)
    rest_pledge = models.DecimalField("限售股份质押数量（万）", max_digits=18, decimal_places=4, null=True)
    total_share = models.DecimalField("总股本", max_digits=18, decimal_places=4, null=True)
    pledge_ratio = models.DecimalField("质押比例", max_digits=18, decimal_places=4, null=True)
    # update_time = models.DateTimeField("修改时间", default=now, editable=False)

    class Meta:
        db_table = 'pledge_stat'
        verbose_name = '股权质押统计'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,end_date,pledge_count,unrest_pledge,rest_pledge,total_share,pledge_ratio'
        ordering = ['-end_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()


class Pledge_Detail(models.Model):
    """
    ts_code 	str 	Y 	TS股票代码
    ann_date 	str 	Y 	公告日期
    holder_name 	str 	Y 	股东名称
    pledge_amount 	float 	Y 	质押数量（万股）
    start_date 	str 	Y 	质押开始日期
    end_date 	str 	Y 	质押结束日期
    is_release 	str 	Y 	是否已解押
    release_date 	str 	Y 	解押日期
    pledgor 	str 	Y 	质押方
    holding_amount 	float 	Y 	持股总数（万股）
    pledged_amount 	float 	Y 	质押总数（万股）
    p_total_ratio 	float 	Y 	本次质押占总股本比例
    h_total_ratio 	float 	Y 	持股总数占总股本比例
    is_buyback 	str 	Y 	是否回购
    """
    ts_code = models.CharField("TS股票代码", max_length=18, null=True, blank=False, db_index=True)
    ann_date = models.CharField("公告日期", max_length=18, null=True, blank=False, db_index=True)
    holder_name = models.CharField("股东名称", max_length=180, null=True, blank=False, db_index=True)
    pledge_amount = models.DecimalField('质押数量（万股）', max_digits=24, decimal_places=4, null=True)
    start_date = models.CharField("质押开始日期", max_length=18, null=True, blank=False, db_index=True)
    end_date = models.CharField("质押结束日期", max_length=18, null=True, blank=False, db_index=True)
    is_release = models.CharField("是否已解押", max_length=18, null=True, blank=False, db_index=True)
    release_date = models.CharField("解押日期", max_length=18, null=True, blank=False, db_index=True)
    pledgor = models.CharField("质押方", max_length=180, null=True, blank=False, db_index=True)
    holding_amount = models.DecimalField('持股总数（万股）', max_digits=24, decimal_places=4, null=True)
    pledged_amount = models.DecimalField('质押总数（万股）', max_digits=24, decimal_places=4, null=True)
    p_total_ratio = models.DecimalField('本次质押占总股本比例', max_digits=24, decimal_places=4, null=True)
    h_total_ratio = models.DecimalField('持股总数占总股本比例', max_digits=24, decimal_places=4, null=True)
    is_buyback = models.CharField("是否回购", max_length=18, null=True, blank=False, db_index=True)

    class Meta:
        db_table = 'pledge_detail'
        verbose_name = '股权质押明细数据'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,holder_name,pledge_amount,start_date,end_date,is_release,release_date,pledgor,holding_amount,pledged_amount,p_total_ratio,h_total_ratio,is_buyback'
        ordering = ['-ann_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()

class CashFlow(models.Model):
    """
    ts_code 	str 	Y 	TS股票代码
    ann_date 	str 	Y 	公告日期
    f_ann_date 	str 	Y 	实际公告日期
    end_date 	str 	Y 	报告期
    comp_type 	str 	Y 	公司类型
    report_type 	str 	Y 	报表类型
    net_profit 	float 	Y 	净利润
    finan_exp 	float 	Y 	财务费用
    c_fr_sale_sg 	float 	Y 	销售商品、提供劳务收到的现金
    recp_tax_rends 	float 	Y 	收到的税费返还
    n_depos_incr_fi 	float 	Y 	客户存款和同业存放款项净增加额
    n_incr_loans_cb 	float 	Y 	向中央银行借款净增加额
    n_inc_borr_oth_fi 	float 	Y 	向其他金融机构拆入资金净增加额
    prem_fr_orig_contr 	float 	Y 	收到原保险合同保费取得的现金
    n_incr_insured_dep 	float 	Y 	保户储金净增加额
    n_reinsur_prem 	float 	Y 	收到再保业务现金净额
    n_incr_disp_tfa 	float 	Y 	处置交易性金融资产净增加额
    ifc_cash_incr 	float 	Y 	收取利息和手续费净增加额
    n_incr_disp_faas 	float 	Y 	处置可供出售金融资产净增加额
    n_incr_loans_oth_bank 	float 	Y 	拆入资金净增加额
    n_cap_incr_repur 	float 	Y 	回购业务资金净增加额
    c_fr_oth_operate_a 	float 	Y 	收到其他与经营活动有关的现金
    c_inf_fr_operate_a 	float 	Y 	经营活动现金流入小计
    c_paid_goods_s 	float 	Y 	购买商品、接受劳务支付的现金
    c_paid_to_for_empl 	float 	Y 	支付给职工以及为职工支付的现金
    c_paid_for_taxes 	float 	Y 	支付的各项税费
    n_incr_clt_loan_adv 	float 	Y 	客户贷款及垫款净增加额
    n_incr_dep_cbob 	float 	Y 	存放央行和同业款项净增加额
    c_pay_claims_orig_inco 	float 	Y 	支付原保险合同赔付款项的现金
    pay_handling_chrg 	float 	Y 	支付手续费的现金
    pay_comm_insur_plcy 	float 	Y 	支付保单红利的现金
    oth_cash_pay_oper_act 	float 	Y 	支付其他与经营活动有关的现金
    st_cash_out_act 	float 	Y 	经营活动现金流出小计
    n_cashflow_act 	float 	Y 	经营活动产生的现金流量净额
    oth_recp_ral_inv_act 	float 	Y 	收到其他与投资活动有关的现金
    c_disp_withdrwl_invest 	float 	Y 	收回投资收到的现金
    c_recp_return_invest 	float 	Y 	取得投资收益收到的现金
    n_recp_disp_fiolta 	float 	Y 	处置固定资产、无形资产和其他长期资产收回的现金净额
    n_recp_disp_sobu 	float 	Y 	处置子公司及其他营业单位收到的现金净额
    stot_inflows_inv_act 	float 	Y 	投资活动现金流入小计
    c_pay_acq_const_fiolta 	float 	Y 	购建固定资产、无形资产和其他长期资产支付的现金
    c_paid_invest 	float 	Y 	投资支付的现金
    n_disp_subs_oth_biz 	float 	Y 	取得子公司及其他营业单位支付的现金净额
    oth_pay_ral_inv_act 	float 	Y 	支付其他与投资活动有关的现金
    n_incr_pledge_loan 	float 	Y 	质押贷款净增加额
    stot_out_inv_act 	float 	Y 	投资活动现金流出小计
    n_cashflow_inv_act 	float 	Y 	投资活动产生的现金流量净额
    c_recp_borrow 	float 	Y 	取得借款收到的现金
    proc_issue_bonds 	float 	Y 	发行债券收到的现金
    oth_cash_recp_ral_fnc_act 	float 	Y 	收到其他与筹资活动有关的现金
    stot_cash_in_fnc_act 	float 	Y 	筹资活动现金流入小计
    free_cashflow 	float 	Y 	企业自由现金流量
    c_prepay_amt_borr 	float 	Y 	偿还债务支付的现金
    c_pay_dist_dpcp_int_exp 	float 	Y 	分配股利、利润或偿付利息支付的现金
    incl_dvd_profit_paid_sc_ms 	float 	Y 	其中:子公司支付给少数股东的股利、利润
    oth_cashpay_ral_fnc_act 	float 	Y 	支付其他与筹资活动有关的现金
    stot_cashout_fnc_act 	float 	Y 	筹资活动现金流出小计
    n_cash_flows_fnc_act 	float 	Y 	筹资活动产生的现金流量净额
    eff_fx_flu_cash 	float 	Y 	汇率变动对现金的影响
    n_incr_cash_cash_equ 	float 	Y 	现金及现金等价物净增加额
    c_cash_equ_beg_period 	float 	Y 	期初现金及现金等价物余额
    c_cash_equ_end_period 	float 	Y 	期末现金及现金等价物余额
    c_recp_cap_contrib 	float 	Y 	吸收投资收到的现金
    incl_cash_rec_saims 	float 	Y 	其中:子公司吸收少数股东投资收到的现金
    uncon_invest_loss 	float 	Y 	未确认投资损失
    prov_depr_assets 	float 	Y 	加:资产减值准备
    depr_fa_coga_dpba 	float 	Y 	固定资产折旧、油气资产折耗、生产性生物资产折旧
    amort_intang_assets 	float 	Y 	无形资产摊销
    lt_amort_deferred_exp 	float 	Y 	长期待摊费用摊销
    decr_deferred_exp 	float 	Y 	待摊费用减少
    incr_acc_exp 	float 	Y 	预提费用增加
    loss_disp_fiolta 	float 	Y 	处置固定、无形资产和其他长期资产的损失
    loss_scr_fa 	float 	Y 	固定资产报废损失
    loss_fv_chg 	float 	Y 	公允价值变动损失
    invest_loss 	float 	Y 	投资损失
    decr_def_inc_tax_assets 	float 	Y 	递延所得税资产减少
    incr_def_inc_tax_liab 	float 	Y 	递延所得税负债增加
    decr_inventories 	float 	Y 	存货的减少
    decr_oper_payable 	float 	Y 	经营性应收项目的减少
    incr_oper_payable 	float 	Y 	经营性应付项目的增加
    others 	float 	Y 	其他
    im_net_cashflow_oper_act 	float 	Y 	经营活动产生的现金流量净额(间接法)
    conv_debt_into_cap 	float 	Y 	债务转为资本
    conv_copbonds_due_within_1y 	float 	Y 	一年内到期的可转换公司债券
    fa_fnc_leases 	float 	Y 	融资租入固定资产
    end_bal_cash 	float 	Y 	现金的期末余额
    beg_bal_cash 	float 	Y 	减:现金的期初余额
    end_bal_cash_equ 	float 	Y 	加:现金等价物的期末余额
    beg_bal_cash_equ 	float 	Y 	减:现金等价物的期初余额
    im_n_incr_cash_equ 	float 	Y 	现金及现金等价物净增加额(间接法)
    update_flag 	str 	N 	更新标识
    """
    ts_code=models.CharField("TS股票代码",max_length=18,null=True,blank=False,db_index=True)
    ann_date=models.CharField("公告日期",max_length=18,null=True,blank=False,db_index=True)
    f_ann_date=models.CharField("实际公告日期",max_length=18,null=True,blank=False,db_index=True)
    end_date=models.CharField("报告期",max_length=18,null=True,blank=False,db_index=True)
    comp_type=models.CharField("公司类型",max_length=18,null=True,blank=False,db_index=True)
    report_type=models.CharField("报表类型",max_length=18,null=True,blank=False,db_index=True)
    net_profit=models.DecimalField('净利润',max_digits=24, decimal_places=2,null=True)
    finan_exp=models.DecimalField('财务费用',max_digits=24, decimal_places=2,null=True)
    c_fr_sale_sg=models.DecimalField('销售商品、提供劳务收到的现金',max_digits=24, decimal_places=2,null=True)
    recp_tax_rends=models.DecimalField('收到的税费返还',max_digits=24, decimal_places=2,null=True)
    n_depos_incr_fi=models.DecimalField('客户存款和同业存放款项净增加额',max_digits=24, decimal_places=2,null=True)
    n_incr_loans_cb=models.DecimalField('向中央银行借款净增加额',max_digits=24, decimal_places=2,null=True)
    n_inc_borr_oth_fi=models.DecimalField('向其他金融机构拆入资金净增加额',max_digits=24, decimal_places=2,null=True)
    prem_fr_orig_contr=models.DecimalField('收到原保险合同保费取得的现金',max_digits=24, decimal_places=2,null=True)
    n_incr_insured_dep=models.DecimalField('保户储金净增加额',max_digits=24, decimal_places=2,null=True)
    n_reinsur_prem=models.DecimalField('收到再保业务现金净额',max_digits=24, decimal_places=2,null=True)
    n_incr_disp_tfa=models.DecimalField('处置交易性金融资产净增加额',max_digits=24, decimal_places=2,null=True)
    ifc_cash_incr=models.DecimalField('收取利息和手续费净增加额',max_digits=24, decimal_places=2,null=True)
    n_incr_disp_faas=models.DecimalField('处置可供出售金融资产净增加额',max_digits=24, decimal_places=2,null=True)
    n_incr_loans_oth_bank=models.DecimalField('拆入资金净增加额',max_digits=24, decimal_places=2,null=True)
    n_cap_incr_repur=models.DecimalField('回购业务资金净增加额',max_digits=24, decimal_places=2,null=True)
    c_fr_oth_operate_a=models.DecimalField('收到其他与经营活动有关的现金',max_digits=24, decimal_places=2,null=True)
    c_inf_fr_operate_a=models.DecimalField('经营活动现金流入小计',max_digits=24, decimal_places=2,null=True)
    c_paid_goods_s=models.DecimalField('购买商品、接受劳务支付的现金',max_digits=24, decimal_places=2,null=True)
    c_paid_to_for_empl=models.DecimalField('支付给职工以及为职工支付的现金',max_digits=24, decimal_places=2,null=True)
    c_paid_for_taxes=models.DecimalField('支付的各项税费',max_digits=24, decimal_places=2,null=True)
    n_incr_clt_loan_adv=models.DecimalField('客户贷款及垫款净增加额',max_digits=24, decimal_places=2,null=True)
    n_incr_dep_cbob=models.DecimalField('存放央行和同业款项净增加额',max_digits=24, decimal_places=2,null=True)
    c_pay_claims_orig_inco=models.DecimalField('支付原保险合同赔付款项的现金',max_digits=24, decimal_places=2,null=True)
    pay_handling_chrg=models.DecimalField('支付手续费的现金',max_digits=24, decimal_places=2,null=True)
    pay_comm_insur_plcy=models.DecimalField('支付保单红利的现金',max_digits=24, decimal_places=2,null=True)
    oth_cash_pay_oper_act=models.DecimalField('支付其他与经营活动有关的现金',max_digits=24, decimal_places=2,null=True)
    st_cash_out_act=models.DecimalField('经营活动现金流出小计',max_digits=24, decimal_places=2,null=True)
    n_cashflow_act=models.DecimalField('经营活动产生的现金流量净额',max_digits=24, decimal_places=2,null=True)
    oth_recp_ral_inv_act=models.DecimalField('收到其他与投资活动有关的现金',max_digits=24, decimal_places=2,null=True)
    c_disp_withdrwl_invest=models.DecimalField('收回投资收到的现金',max_digits=24, decimal_places=2,null=True)
    c_recp_return_invest=models.DecimalField('取得投资收益收到的现金',max_digits=24, decimal_places=2,null=True)
    n_recp_disp_fiolta=models.DecimalField('处置固定资产、无形资产和其他长期资产收回的现金净额',max_digits=24, decimal_places=2,null=True)
    n_recp_disp_sobu=models.DecimalField('处置子公司及其他营业单位收到的现金净额',max_digits=24, decimal_places=2,null=True)
    stot_inflows_inv_act=models.DecimalField('投资活动现金流入小计',max_digits=24, decimal_places=2,null=True)
    c_pay_acq_const_fiolta=models.DecimalField('购建固定资产、无形资产和其他长期资产支付的现金',max_digits=24, decimal_places=2,null=True)
    c_paid_invest=models.DecimalField('投资支付的现金',max_digits=24, decimal_places=2,null=True)
    n_disp_subs_oth_biz=models.DecimalField('取得子公司及其他营业单位支付的现金净额',max_digits=24, decimal_places=2,null=True)
    oth_pay_ral_inv_act=models.DecimalField('支付其他与投资活动有关的现金',max_digits=24, decimal_places=2,null=True)
    n_incr_pledge_loan=models.DecimalField('质押贷款净增加额',max_digits=24, decimal_places=2,null=True)
    stot_out_inv_act=models.DecimalField('投资活动现金流出小计',max_digits=24, decimal_places=2,null=True)
    n_cashflow_inv_act=models.DecimalField('投资活动产生的现金流量净额',max_digits=24, decimal_places=2,null=True)
    c_recp_borrow=models.DecimalField('取得借款收到的现金',max_digits=24, decimal_places=2,null=True)
    proc_issue_bonds=models.DecimalField('发行债券收到的现金',max_digits=24, decimal_places=2,null=True)
    oth_cash_recp_ral_fnc_act=models.DecimalField('收到其他与筹资活动有关的现金',max_digits=24, decimal_places=2,null=True)
    stot_cash_in_fnc_act=models.DecimalField('筹资活动现金流入小计',max_digits=24, decimal_places=2,null=True)
    free_cashflow=models.DecimalField('企业自由现金流量',max_digits=24, decimal_places=4,null=True)
    c_prepay_amt_borr=models.DecimalField('偿还债务支付的现金',max_digits=24, decimal_places=2,null=True)
    c_pay_dist_dpcp_int_exp=models.DecimalField('分配股利、利润或偿付利息支付的现金',max_digits=24, decimal_places=2,null=True)
    incl_dvd_profit_paid_sc_ms=models.DecimalField('其中:子公司支付给少数股东的股利、利润',max_digits=24, decimal_places=2,null=True)
    oth_cashpay_ral_fnc_act=models.DecimalField('支付其他与筹资活动有关的现金',max_digits=24, decimal_places=2,null=True)
    stot_cashout_fnc_act=models.DecimalField('筹资活动现金流出小计',max_digits=24, decimal_places=2,null=True)
    n_cash_flows_fnc_act=models.DecimalField('筹资活动产生的现金流量净额',max_digits=24, decimal_places=2,null=True)
    eff_fx_flu_cash=models.DecimalField('汇率变动对现金的影响',max_digits=24, decimal_places=2,null=True)
    n_incr_cash_cash_equ=models.DecimalField('现金及现金等价物净增加额',max_digits=24, decimal_places=2,null=True)
    c_cash_equ_beg_period=models.DecimalField('期初现金及现金等价物余额',max_digits=24, decimal_places=2,null=True)
    c_cash_equ_end_period=models.DecimalField('期末现金及现金等价物余额',max_digits=24, decimal_places=2,null=True)
    c_recp_cap_contrib=models.DecimalField('吸收投资收到的现金',max_digits=24, decimal_places=2,null=True)
    incl_cash_rec_saims=models.DecimalField('其中:子公司吸收少数股东投资收到的现金',max_digits=24, decimal_places=2,null=True)
    uncon_invest_loss=models.DecimalField('未确认投资损失',max_digits=24, decimal_places=2,null=True)
    prov_depr_assets=models.DecimalField('加:资产减值准备',max_digits=24, decimal_places=2,null=True)
    depr_fa_coga_dpba=models.DecimalField('固定资产折旧、油气资产折耗、生产性生物资产折旧',max_digits=24, decimal_places=2,null=True)
    amort_intang_assets=models.DecimalField('无形资产摊销',max_digits=24, decimal_places=2,null=True)
    lt_amort_deferred_exp=models.DecimalField('长期待摊费用摊销',max_digits=24, decimal_places=2,null=True)
    decr_deferred_exp=models.DecimalField('待摊费用减少',max_digits=24, decimal_places=2,null=True)
    incr_acc_exp=models.DecimalField('预提费用增加',max_digits=24, decimal_places=2,null=True)
    loss_disp_fiolta=models.DecimalField('处置固定、无形资产和其他长期资产的损失',max_digits=24, decimal_places=2,null=True)
    loss_scr_fa=models.DecimalField('固定资产报废损失',max_digits=24, decimal_places=2,null=True)
    loss_fv_chg=models.DecimalField('公允价值变动损失',max_digits=24, decimal_places=2,null=True)
    invest_loss=models.DecimalField('投资损失',max_digits=24, decimal_places=2,null=True)
    decr_def_inc_tax_assets=models.DecimalField('递延所得税资产减少',max_digits=24, decimal_places=2,null=True)
    incr_def_inc_tax_liab=models.DecimalField('递延所得税负债增加',max_digits=24, decimal_places=2,null=True)
    decr_inventories=models.DecimalField('存货的减少',max_digits=24, decimal_places=2,null=True)
    decr_oper_payable=models.DecimalField('经营性应收项目的减少',max_digits=24, decimal_places=2,null=True)
    incr_oper_payable=models.DecimalField('经营性应付项目的增加',max_digits=24, decimal_places=2,null=True)
    others=models.DecimalField('其他',max_digits=24, decimal_places=2,null=True)
    im_net_cashflow_oper_act=models.DecimalField('经营活动产生的现金流量净额(间接法)',max_digits=24, decimal_places=2,null=True)
    conv_debt_into_cap=models.DecimalField('债务转为资本',max_digits=24, decimal_places=2,null=True)
    conv_copbonds_due_within_1y=models.DecimalField('一年内到期的可转换公司债券',max_digits=24, decimal_places=2,null=True)
    fa_fnc_leases=models.DecimalField('融资租入固定资产',max_digits=24, decimal_places=2,null=True)
    end_bal_cash=models.DecimalField('现金的期末余额',max_digits=24, decimal_places=2,null=True)
    beg_bal_cash=models.DecimalField('减:现金的期初余额',max_digits=24, decimal_places=2,null=True)
    end_bal_cash_equ=models.DecimalField('加:现金等价物的期末余额',max_digits=24, decimal_places=2,null=True)
    beg_bal_cash_equ=models.DecimalField('减:现金等价物的期初余额',max_digits=24, decimal_places=2,null=True)
    im_n_incr_cash_equ=models.DecimalField('现金及现金等价物净增加额(间接法)',max_digits=24, decimal_places=2,null=True)
    update_flag=models.CharField("更新标识",max_length=18,null=True,blank=False,db_index=True)

    class Meta:
        db_table = 'cashflow'
        verbose_name = '现金流量表'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,f_ann_date,end_date,comp_type,report_type,net_profit,finan_exp,c_fr_sale_sg,recp_tax_rends,n_depos_incr_fi,n_incr_loans_cb,n_inc_borr_oth_fi,prem_fr_orig_contr,n_incr_insured_dep,n_reinsur_prem,n_incr_disp_tfa,ifc_cash_incr,n_incr_disp_faas,n_incr_loans_oth_bank,n_cap_incr_repur,c_fr_oth_operate_a,c_inf_fr_operate_a,c_paid_goods_s,c_paid_to_for_empl,c_paid_for_taxes,n_incr_clt_loan_adv,n_incr_dep_cbob,c_pay_claims_orig_inco,pay_handling_chrg,pay_comm_insur_plcy,oth_cash_pay_oper_act,st_cash_out_act,n_cashflow_act,oth_recp_ral_inv_act,c_disp_withdrwl_invest,c_recp_return_invest,n_recp_disp_fiolta,n_recp_disp_sobu,stot_inflows_inv_act,c_pay_acq_const_fiolta,c_paid_invest,n_disp_subs_oth_biz,oth_pay_ral_inv_act,n_incr_pledge_loan,stot_out_inv_act,n_cashflow_inv_act,c_recp_borrow,proc_issue_bonds,oth_cash_recp_ral_fnc_act,stot_cash_in_fnc_act,free_cashflow,c_prepay_amt_borr,c_pay_dist_dpcp_int_exp,incl_dvd_profit_paid_sc_ms,oth_cashpay_ral_fnc_act,stot_cashout_fnc_act,n_cash_flows_fnc_act,eff_fx_flu_cash,n_incr_cash_cash_equ,c_cash_equ_beg_period,c_cash_equ_end_period,c_recp_cap_contrib,incl_cash_rec_saims,uncon_invest_loss,prov_depr_assets,depr_fa_coga_dpba,amort_intang_assets,lt_amort_deferred_exp,decr_deferred_exp,incr_acc_exp,loss_disp_fiolta,loss_scr_fa,loss_fv_chg,invest_loss,decr_def_inc_tax_assets,incr_def_inc_tax_liab,decr_inventories,decr_oper_payable,incr_oper_payable,others,im_net_cashflow_oper_act,conv_debt_into_cap,conv_copbonds_due_within_1y,fa_fnc_leases,end_bal_cash,beg_bal_cash,end_bal_cash_equ,beg_bal_cash_equ,im_n_incr_cash_equ,update_flag'
        ordering = ['-ann_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()

class Stk_HolderNumber(models.Model):
    """
    ts_code 	str 	Y 	TS股票代码
    ann_date 	str 	Y 	公告日期
    end_date 	str 	Y 	截止日期
    holder_num 	int 	Y 	股东户数
    """
    ts_code = models.CharField('TS股票代码',max_length=18,null=True, blank=False, db_index=True)
    ann_date = models.CharField('公告日期',max_length=18,null=True, blank=False, db_index=True)
    end_date = models.CharField('截止日期',max_length=18,null=True, blank=False, db_index=True)
    holder_num = models.IntegerField('股东户数',null=True, blank=False, db_index=True)
    class Meta:
        db_table = 'stk_holdernumber'
        verbose_name = '股东人数'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,end_date,holder_num'
        ordering = ['-ann_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.end_date)

    def __repr__(self):
        return self.__str__()

class Stk_HolderTrade(models.Model):
    """
    名称 	类型 	默认显示 	描述
    ts_code 	str 	Y 	TS代码
    ann_date 	str 	Y 	公告日期
    holder_name 	str 	Y 	股东名称
    holder_type 	str 	Y 	股东类型G高管P个人C公司
    in_de 	str 	Y 	类型IN增持DE减持
    change_vol 	float 	Y 	变动数量
    change_ratio 	float 	Y 	占流通比例（%）
    after_share 	float 	Y 	变动后持股
    after_ratio 	float 	Y 	变动后占流通比例（%）
    avg_price 	float 	Y 	平均价格
    total_share 	float 	Y 	持股总数
    begin_date 	str 	N 	增减持开始日期
    close_date 	str 	N 	增减持结束日期
    """
    
    ts_code = models.CharField("TS代码",max_length=18,null=True,blank=False,db_index=True)
    ann_date = models.CharField("公告日期",max_length=18,null=True,blank=False,db_index=True)
    holder_name = models.CharField("股东名称",max_length=180,null=True,blank=False,db_index=True)
    holder_type = models.CharField("股东类型G高管P个人C公司",max_length=180,null=True)
    in_de = models.CharField("类型IN增持DE减持",max_length=12,null=True)
    change_vol = models.DecimalField("变动数量",max_digits=24, decimal_places=2,null=True)
    change_ratio = models.DecimalField("占流通比例（%）",max_digits=24, decimal_places=4,null=True)
    after_share = models.DecimalField("变动后持股",max_digits=24, decimal_places=4,null=True)
    after_ratio = models.DecimalField("变动后占流通比例（%）",max_digits=24, decimal_places=4,null=True)
    avg_price = models.DecimalField("平均价格",max_digits=24, decimal_places=4,null=True)
    total_share = models.DecimalField("持股总数",max_digits=24, decimal_places=4,null=True)
    begin_date = models.CharField("增减持开始日期",max_length=18,null=True)
    close_date = models.CharField("增减持结束日期",max_length=18,null=True)


    class Meta:
        db_table = 'stk_holdertrade'
        verbose_name = '股东增减持'
        verbose_name_plural = verbose_name
        df_fields = 'ts_code,ann_date,holder_name,holder_type,in_de,change_vol,change_ratio,after_share,after_ratio,avg_price,total_share,begin_date,close_date'
        ordering = ['-ann_date','ts_code']

    def __str__(self):
        return "[%s] %s:%s" % (self.__class__.__name__, self.ts_code, self.ann_date)

    def __repr__(self):
        return self.__str__()

class Trade_Cal(models.Model):
    """
    名称 	类型 	默认显示 	描述
    exchange 	str 	Y 	交易所 SSE上交所 SZSE深交所
    cal_date 	str 	Y 	日历日期
    is_open 	str 	Y 	是否交易 0休市 1交易
    pretrade_date 	str 	N 	上一个交易日
    """
    exchange = models.CharField("交易所 SSE上交所 SZSE深交所",max_length=18)
    cal_date = models.CharField("日历日期",max_length=18)
    is_open = models.CharField("是否交易 0休市 1交易",max_length=18,null=True)
    pretrade_date = models.CharField("上一个交易日",max_length=18,null=True)

    class Meta:
        db_table = 'trade_cal'
        verbose_name = '交易日历'
        verbose_name_plural = verbose_name
        df_fields = 'exchange,cal_date,is_open,pretrade_date'
        unique_together=(('exchange','cal_date'),)
        ordering = ['-cal_date']

    def __str__(self):
        return "[%s] %s:%s:%s" % (self.__class__.__name__, self.cal_date, self.is_open,self.pretrade_date)

    def __repr__(self):
        return self.__str__()
