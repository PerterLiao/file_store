from scheduler.models import *
from scheduler.utils import *

"""
     如果mysql中有数据 ，则覆盖
    0. 先执行mysel的数据清除
    1. 追加数据到mysql
"""
"""
 Basic 全量直接获取
 NameChange 遍历Basic 批量获取
 Daily 遍历年份分次获取 
 Daily_Basic 变量年份/月份分次获取
 Income_vip 季度获取
 Balancesheet_vip 季度获取
 Cashflow_vip 季度获取
 forecast_vip period 获取
 express_vip 
 fina_indicator_vip 
 pledge_detail 遍历ts_code获取
 pledge_stat ...
 stk_holdernumber ...
"""


def pull_basic():
    '''
    Basic
    全量直接获取
    '''
    df = DataFrame()
    Basic.objects.all().delete()
    fields=Basic._meta.df_fields

    for _ in range(3):
        try:
            df = pro.stock_basic(fields=fields)
        except:
            time.sleep(1)
        else:
            break
    save_data('basic',df)
def pull_namechange():
    df=None
    '''
     NameChange 遍历Basic 批量获取
    '''
    NameChange.objects.all().delete()
    fields=NameChange._meta.df_fields
    ts_codes = get_codes()
    for ts_code in ts_codes:
        for _ in range(3):
            try:
                df = pro.namechange(ts_code=ts_code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('namechange',df)
def pull_daily():
    df=None
    '''
     Daily 遍历按日分次获取 日线行情
    '''
    Daily.objects.all().delete()
    fields = Daily._meta.df_fields
    #days = get_days()
    ts_codes = get_codes()
    #for day in days:
    for ts_code in ts_codes:

        for _ in range(3):
            try:
                df = pro.daily(ts_code = ts_code,fields=fields)
                #df = pro.daily(trade_date=day,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('daily',df)

def pull_dailybasic():
    df=None
    '''
     Daily_Basic 日份分次获取 每日指标
    '''
    DailyBasic.objects.all().delete()
    fields = DailyBasic._meta.df_fields
    #days = get_days()
    ts_codes = get_codes()
    #for day in days:
    for ts_code in ts_codes:
        for _ in range(3):
            try:
                #df = pro.daily_basic(ts_code='',trade_date=day,fields=fields)
                df = pro.daily_basic(ts_code=ts_code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('dailybasic',df)
    # 按日获取
'''
 Income_vip 季度获取
'''
def pull_income():
    df=None
    Income.objects.all().delete()
    fields = Income._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    for ts in choice.income_report_type:
        #for period in periods:
        for ts_code in ts_codes:
            for _ in range(3):
                try:
                    #df = pro.income_vip(period=period,report_type=ts[0],fields=fields)
                    df = pro.income_vip(ts_code=ts_code,report_type=ts[0],fields=fields)
                except:
                    time.sleep(1)
                else:
                    break
            save_data('income',df)
'''
 Balancesheet_vip 季度获取
'''
def pull_balancesheet():
    df=None
    BalanceSheet.objects.all().delete()
    fields = BalanceSheet._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    for ts in choice.income_report_type:
        #for period in periods:
        for ts_code in ts_codes:
            for _ in range(3):
                try:
                    #df = pro.balancesheet_vip(period=period,report_type=ts[0],fields=fields)
                    df = pro.balancesheet_vip(ts_code=ts_code,report_type=ts[0],fields=fields)
                except:
                    time.sleep(1)
                else:
                    break
            save_data('balancesheet',df)
'''
 Cashflow_vip 季度获取
'''
def pull_cashflow():
    df=None
    CashFlow.objects.all().delete()
    fields = CashFlow._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    for ts in choice.income_report_type:
        #for period in periods:
        for ts_code in ts_codes:
            for _ in range(3):
                try:
                    #df = pro.cashflow_vip(period = period,report_type=ts[0],fields=fields)
                    df = pro.cashflow_vip(ts_code = ts_code,report_type=ts[0],fields=fields)
                except:
                    time.sleep(1)
                else:break
            save_data('cashflow',df)

'''
 forecast_vip period 获取
'''
def pull_forecast():
    df=None
    Forecast.objects.all().delete()
    fields = Forecast._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    #for period in periods:
    for ts_code in ts_codes:
        for _ in range(3):
            try:
                #df = pro.forecast_vip(period=period,fields=fields)
                df = pro.forecast_vip(ts_code=ts_code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('forecast',df)

'''
express_vip 季度获取
'''
def pull_express():
    df=None
    Express.objects.all().delete()
    fields = Express._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    #for period in periods:
    for ts_code in ts_codes:

        for _ in range(3):
            try:
                #df = pro.express_vip(period = period,fields=fields)
                df = pro.express_vip(ts_code=ts_code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('express',df)

# '''
# fina_indicator_vip
# '''
def pull_finaindicator():
    df=None
    FinaIndicator.objects.all().delete()
    fields = FinaIndicator._meta.df_fields
    #periods = get_periods()
    ts_codes = get_codes()
    #for period in periods:
    for ts_code in ts_codes:
        for _ in range(3):
            try:
                df = pro.fina_indicator_vip(ts_code = ts_code,fields = fields)
                #df = pro.fina_indicator_vip(period = period,fields = fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('finaindicator',df)
'''
pledge_detail
'''
def pull_pledge_detail():
    df=None
    Pledge_Detail.objects.all().delete()
    fields = Pledge_Detail._meta.df_fields
    ts_codes = get_codes()
    for code in ts_codes:
        for _ in range(3):
            try:
                df = pro.pledge_detail(ts_code=code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('pledge_detail',df)

'''
pledge_stat...
'''
def pull_pledge_stat():
    df=None
    Pledge_Stat.objects.all().delete()
    fields = Pledge_Stat._meta.df_fields
    ts_codes = get_codes()
    for code in ts_codes:
        for _ in range(3):
            try:
                df = pro.pledge_stat(ts_code=code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('pledge_stat',df)
'''
stk_holdernumber...
'''
def pull_stk_holdernumber():
    df=None
    Stk_HolderNumber.objects.all().delete()
    fields = Stk_HolderNumber._meta.df_fields
    ts_codes = get_codes()
    for code in ts_codes:
        for _ in range(3):
            try:
                df = pro.stk_holdernumber(ts_code=code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('stk_holdernumber',df)

""" 
stk_holdertrade 
"""
def pull_stk_holdertrade():
    df=None
    Stk_HolderTrade.objects.all().delete()
    fields = Stk_HolderTrade._meta.df_fields
    ts_codes = get_codes()
    for code in ts_codes:
        for _ in range(3):
            try:
                df = pro.stk_holdertrade(ts_code=code,fields=fields)
            except:
                time.sleep(1)
            else:
                break
        save_data('stk_holdertrade',df)

def pull_trade_cal():
    df=None
    Trade_Cal.objects.all().delete()
    fields = Trade_Cal._meta.df_fields
    for _ in range(3):
        try:
            df = pro.trade_cal(fields=fields)
        except:
            time.sleep(1)
        else:
            break
    save_data('trade_cal',df)

def pull_tables():
    print('加载股票列表')
    pull_basic()
    print('加载历史变更')
    pull_namechange()
    print('加载日线指标')
    pull_dailybasic()
    print('加载日线行情')
    pull_daily()
    print('加载快报')
    pull_express()
    print('加载预报')
    pull_forecast()
    print('加载财务指标')
    pull_finaindicator()
    print('加载现金流量')
    pull_cashflow()
    print('加载资产负债')
    pull_balancesheet()
    print('加载利润')
    pull_income()
    print('加载质押统计')
    pull_pledge_stat()
    print('加载质押明细')
    pull_pledge_detail()
    print('加载股东人数')
    pull_stk_holdernumber()
    print('加载增减持')
    pull_stk_holdertrade()
    print('加载交易日历')
    pull_trade_cal()

def delete_data():
    print("删除日线行情")
    Daily.objects.all().delete()
    print("删除日线指标")
    DailyBasic.objects.all().delete()
    
