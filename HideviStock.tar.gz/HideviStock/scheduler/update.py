from time import sleep

from scheduler.models import *
from scheduler.utils import *
"""
basic 全量更新
namechange  根据公告日期更新
daily   根据交易日期更新
daily_basic 根据交易日期更新
express 根据公告日期
balancesheet  根据公告日期更新  
fina_indicator  根据公告日期更新  
forecast  根据公告日期更新  
income  根据公告日期更新  
cashflow  根据公告日期更新  
pledge_stat
pledge_detail
stk_hodlernumber
stk_holdertrade

"""

def update_namechange(last_day=None):
    """   根据日期更新"""
    df = None
    fields=NameChange._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.namechange(ts_code='',start_date=last_day,fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('namechange',df)

def update_daily(last_day=None):
    """   根据交易日期更新"""
    df = None
    fields=Daily._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.daily(ts_code='',trade_date=last_day,fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('daily',df)

def update_dailybasic(last_day=None):
    """ 根据交易日期更新"""
    df = None
    fields=DailyBasic._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.daily_basic(ts_code='',trade_date=last_day,fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('dailybasic',df)

def update_express(last_day=None):
    """ 根据公告日期"""
    df = None
    fields=Express._meta.df_fields
    if last_day== None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.express_vip(ts_code='',ann_date=last_day,fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('express',df)

def update_balancesheet(last_day=None):
    """  根据公告日期更新  """
    df = None
    fields = BalanceSheet._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.balancesheet_vip(ts_code='',report_type=ts[0],ann_date=last_day, fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('balancesheet', df)
def update_finaindicator(last_day=None):
    """  根据公告日期更新  """
    df = None
    fields = FinaIndicator._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.fina_indicator_vip(ts_code='',ann_date=last_day, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('finaindicator', df)

def update_forecast(last_day=None):
    """  根据公告日期更新  """
    df = None
    fields = Forecast._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.forecast_vip(ts_code='',ann_date=last_day, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('forecast', df)

def update_income(last_day=None):
    """  根据公告日期更新  """
    df = None
    fields = Income._meta.df_fields
    if last_day==None:
        last_day = get_last_day()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.income_vip(ts_code='',report_type=ts[0],ann_date=last_day, fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('income', df)

def update_cashflow(last_day=None):
    """  根据公告日期更新  """
    df = None
    fields = CashFlow._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.cashflow_vip(ts_code='',report_type=ts[0],ann_date=last_day, fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('cashflow', df)

def update_stk_holdernumber(last_day=None):
    """ 根据 公告日期更新 """
    df = None
    fields = Stk_HolderNumber._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.stk_holdernumber(ts_code='',start_date=last_day, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('stk_holdernumber', df)
def update_stk_holdertrade(last_day=None):
    """ 根据 公告日期更新 """
    df = None
    fields = Stk_HolderTrade._meta.df_fields
    if last_day == None:
        last_day = get_last_day()
    for _ in range(3):
        try:
            df = pro.stk_holdertrade(ts_code='',ann_date=last_day, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('stk_holdertrade', df)

def update_express_period(period=None):
    """ 根据公告日期"""
    df = None
    fields=Express._meta.df_fields
    if period== None:
        period = get_last_period()
    for _ in range(3):
        try:
            df = pro.express_vip(period=period,fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('express',df)

def update_balancesheet_period(period=None):
    """  根据公告日期更新  """
    df = None
    fields = BalanceSheet._meta.df_fields
    if period == None:
        period = get_last_period()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.balancesheet_vip(period=period,report_type=ts[0], fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('balancesheet', df)
def update_finaindicator_period(period=None):
    """  根据公告日期更新  """
    df = None
    fields = Finaindicator._meta.df_fields
    if period == None:
        period = get_last_period()
    for _ in range(3):
        try:
            df = pro.fina_indicator_vip(period=period, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('finaindicator', df)

def update_forecast_period(period=None):
    """  根据公告日期更新  """
    df = None
    fields = Forecast._meta.df_fields
    if period == None:
        period = get_last_period()
    for _ in range(3):
        try:
            df = pro.forecast_vip(period=period, fields=fields)
        except:
            sleep(1)
        else:
            break
    save_data('forecast', df)

def update_income_period(period=None):
    """  根据公告日期更新  """
    df = None
    fields = Income._meta.df_fields
    if period==None:
        period = get_last_period()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.income_vip(period=period,report_type=ts[0], fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('income', df)

def update_cashflow_period(period=None):
    """  根据公告日期更新  """
    df = None
    fields = Cashflow._meta.df_fields
    if period == None:
        period = get_last_period()
    for ts in choice.income_report_type:
        for _ in range(3):
            try:
                df = pro.cashflow_vip(period=period,report_type=ts[0], fields=fields)
            except:
                sleep(1)
            else:
                break
        save_data('cashflow', df)

