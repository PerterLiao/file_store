import datetime
import time
import pandas as pd
import tushare as ts
from pandas import DataFrame
from sqlalchemy import create_engine
from scheduler.models import ApiSecret

#engine =  create_engine('mysql+pymysql://root:123456@192.168.1.48:3306/hidevi_stock?charset=utf8')
#engine =  create_engine('mysql+pymysql://root:123456@192.168.43.218:3306/hidevi_stock?charset=utf8')
engine =  create_engine('mysql+pymysql://root:123456@192.168.2.165:3306/hidevi_stock?charset=utf8')

def save_data(table_name:str,data_frame:DataFrame):
    """
    将非空 数据 保存到 表中
    :param table_name:
    :param data_frame:
    :return:
    """
    if not (data_frame is None or len(data_frame) == 0):
        data_frame.to_sql(table_name,engine,if_exists='append',index=False)


def get_token():
    token = ApiSecret.objects.last().secret
    #token = '2b57771b271e66329414435ee57fd248279410c86c7347903e33eab4'
    return token

pro = ts.pro_api(get_token())
def get_codes():
    """
    获取所有 ts_code 编码
    :return:
    """
    df = pd.read_sql('basic',engine)
    ts_codes=df['ts_code']
    #return ts_codes
    return ['688001.SH','688002.SH','000006.SZ','688596.SH','603083.SH','603499.SH','002918.SZ','000030.SZ','002019.SZ','002020.SZ']


#def get_periods(start_year=None, end_year=None):
def get_periods(start_year=2020,end_year=None):
    """
    获取 从 start_yearn 开始 到目前的所有季度截至日期
    :param start_year:
    :param end_yarn:
    :return:
    """
    if start_year == None:
        start_year = 2020
    if end_year == None:
        end_year =datetime.datetime.now().year 
    periods = []
    for year in range(start_year,end_year):
        periods.append(str(year)+'0331')
        periods.append(str(year)+'0630')
        periods.append(str(year)+'0930')
        periods.append(str(year)+'1231')
    month = datetime.datetime.now().month
    if month > 3:
        periods.append(str(end_year)+'0331')
    if month > 6:
        periods.append(str(end_year)+'0630')
    if month > 9:
        periods.append(str(end_year)+'0930')
    #return periods
    return ['20200630',]



def get_days(begin_date="20200715"):
    """
    获取从哪天开始到目前的所有日期
    :param begin_date:
    :return:
    """
    day_list = []
    begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
    end_date = datetime.datetime.strptime(time.strftime("%Y%m%d",time.localtime(time.time())),"%Y%m%d")
    while begin_date <= end_date:
        date_str = begin_date.strftime("%Y%m%d")
        day_list.append(date_str)
        begin_date += datetime.timedelta(days=1)
    return day_list

def get_last_period(date=None):
    """
    获取到给定   日期为止 的 上一级度最后一天日期 eg:'20200630'
    :param date:
    :return: period
    """
    if date==None:
        date=datetime.datetime.now()
    year = date.year
    month = date.month
    if month > 9:
        period = str(year) + "0930"
        return period
    if month > 6:
        period = str(year) + "0630"
        return period
    if month > 3 :
        period = str(year) + "0331"
        return period
    if month <=3 :
        year_last = year - 1
        period = str(year_last) + "1231"
        return period

def get_last_day(date=None):
    """
    获取上一天日期字符串
    :param date:
    :return:
    """
    if date == None:
        date=datetime.datetime.now()
    #date = date - datetime.timedelta(days=1)
    last_day = datetime.datetime.strftime(date,'%Y%m%d')
    return  last_day

def get_month_frist_day(date=None):
    """
    获取日期前一天所在月的第一天
    """
    if date == None:
        date=datetime.datetime.now()-datetime.timedelta(days=1)
    else:
        date = datetime.datetime.strptime('%Y%m%d',date)
    year = date.year
    month = date.month
    month_frist_day = str(year)+str(month)+'01'
    return month_frist_day
