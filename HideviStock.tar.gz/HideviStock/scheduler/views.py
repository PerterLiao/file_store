from django.contrib import messages, auth

from apscheduler.triggers.cron import CronTrigger
from django.shortcuts import render, redirect
from django.template import loader, context
from django.http import HttpResponse,HttpResponseRedirect, HttpResponseNotFound
from django.apps import apps
from django.contrib.auth.decorators import login_required
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.models import DjangoJob,DjangoJobExecution,DjangoJobExecutionManager,DjangoJobManager
from django_apscheduler.jobstores import DjangoJobStore,register_events
from scheduler.update import *
from scheduler.pull import *
from scheduler.report import *
from django.views.decorators.clickjacking import xframe_options_sameorigin


schedule = BackgroundScheduler()
schedule.add_jobstore(DjangoJobStore(),'default')
register_events(schedule)
schedule.start()

# Create your views here.
@login_required
@xframe_options_sameorigin
def scheduler(request):
    task_type = request.GET.get("task_type")
    context={}
    if task_type=="cron":
        data= list(DjangoJob.objects.values())
        fields = []
        for f in DjangoJob._meta.fields:
            fields.append(f.name)
        context={'data':data,
                'fields':fields}
        template = loader.get_template('scheduler/scheduler_cron.html')
        return HttpResponse(template.render(context,request))
    elif task_type == 'listener':
        data = list(DjangoJobExecution.objects.values())
        fields = []
        for f in DjangoJobExecution._meta.fields:
            fields.append(f.name)
        context = {'data':data,
                'fields':fields}
        template = loader.get_template('scheduler/scheduler_listener.html')
        return HttpResponse(template.render(context,request))
    else:
        data= list(DjangoJob.objects.values())
        fields = []
        for f in DjangoJob._meta.fields:
            fields.append(f.name)
        context={'data':data,
                'fields':fields}
        template = loader.get_template("scheduler/scheduler_tmp.html")
        return HttpResponse(template.render(context,request))

@login_required
@xframe_options_sameorigin
def add_cron_job(request):
    if request.method == 'POST':
        job_id = request.POST.get('id')
        table_name = request.POST.get('table_name')
        update_type = request.POST.get("update_type","all")
        cron_min = request.POST.get("cron_min","*")
        cron_hour = request.POST.get("cron_hour","*")
        cron_day = request.POST.get("cron_day","*")
        cron_month = request.POST.get("cron_month","*")
        cron_week = request.POST.get("cron_week","*")
        if cron_min == '':
            cron_min = '*'
        if cron_hour =='':
            cron_hour = '*'
        if cron_day == '':
            cron_day = '*'
        if cron_month == '':
            cron_month = '*'
        if cron_week == '':
            cron_week = '*'
        crons = [cron_min,cron_hour,cron_day,cron_month,cron_week]
        cron_rule = " ".join(crons)
        if job_id == "" or table_name == "":
            return render(request,"scheduler/notfound.html")
        status = job_add(job_id,table_name,update_type,kwargs={"cron_rule":cron_rule})
        if status :
            return redirect("/scheduler/scheduler/?task_type=cron")
        else:
            return render(request,"scheduler/failed.html")
    else:
        return redirect("/scheduler/scheduler/?task_type=cron")

        
@login_required
@xframe_options_sameorigin
def add_tmp_job(request):
    if request.method == 'POST':
        job_id = request.POST.get('id')
        table_name = request.POST.get('table_name')
        update_type = request.POST.get("update_type","all")
        update_value = request.POST.get("update_value","")
        if job_id == "" or table_name == "":
            return render(request,"scheduler/notfound.html")
        status = job_add(job_id,table_name,update_type,kwargs={"update_value":update_value})
        if status :
            return redirect("/scheduler/scheduler/?task_type=tmp")
        else:
            return render(request,"scheduler/failed.html")
    else:
        return redirect("/scheduler/scheduler/?task_type=tmp")

def job_add(job_id=None,table_name=None,update_type=None,kwargs={}):
    if job_id == None or table_name == None :
        return False
    cron_rule = kwargs.get("cron_rule") 
    update_value = kwargs.get('update_value')
    func=None
    if table_name in ['basic','trade_cal'] or update_type == 'all':
        func = get_fun_by_all(table_name)
    elif update_type == 'date':
        func = get_fun_by_date(table_name)
    elif update_type == 'period':
        func = get_fun_by_period(table_name)
    else:
        return False
    if cron_rule:
        trigger=CronTrigger.from_crontab(cron_rule)
    else:
        trigger='date'
    if update_value == "" or update_value == None:
        schedule.add_job(func,id=job_id,trigger=trigger)
    else :
        schedule.add_job(func,id=job_id,trigger=trigger,args=[update_value])

    return True

def get_fun_by_all(table_name=None):
    if table_name == 'basic':
        return pull_basic
    elif table_name == 'namechange':
        return pull_namechange
    elif table_name == 'daily':
        return pull_daily
    elif table_name == 'dailybasic':
        return pull_dailybasic
    elif table_name == 'income':
        return pull_income
    elif table_name == 'forecast':
        return pull_forecast
    elif table_name == 'finaindicator':
        return pull_finaindicator
    elif table_name == 'balancesheet':
        return pull_balancesheet
    elif table_name == 'express':
        return pull_express
    elif table_name == 'cashflow':
        return pull_cashflow
    elif table_name== 'pledge_stat':
        return pull_pledge_stat
    elif table_name == 'pledge_detail':
        return pull_pledge_detail
    elif table_name == 'stk_holdernumber':
        return pull_stk_holdernumber
    elif table_name == 'stk_holdertrade':
        return pull_stk_holdertrade
    elif table_name == 'trade_cal':
        return pull_trade_cal
    else:
        return None

def get_fun_by_date(table_name):
    if table_name == 'namechange':
        return update_namechange
    elif table_name == 'daily':
        return update_daily
    elif table_name == 'dailybasic':
        return update_dailybasic
    elif table_name == 'income':
        return update_income
    elif table_name == 'balancesheet':
        return update_balancesheet
    elif table_name == 'cashflow':
        return update_cashflow
    elif table_name == 'forecast':
        return update_forecast
    elif table_name == 'finaindicator':
        return update_finaindicator
    elif table_name == 'express':
        return update_express
    elif table_name == 'stk_holdernumber':
        return update_stk_holdernumber
    elif table_name == 'stk_holdertrade':
        return update_stk_holdertrade
    elif table_name == 'report_stat':
        return run_report_stat
    else:
        return None

def get_fun_by_period(table_name):
    if table_name == 'income':
        return update_income_period
    elif table_name == 'balancesheet':
        return update_balancesheet_period
    elif table_name == 'cashflow':
        return update_cashflow_period
    elif table_name == 'forecast':
        return update_forecast_period
    elif table_name == 'finaindicator':
        return update_finaindicator_period
    elif table_name == 'express':
        return update_express_period
    else:
        return None
    


def job_remove(request):
    if request.method == 'POST':
        job_id = request.POST.get('job_name','')
        if job_id != '':
            schedule.remove_job(job_id)
    #返回原页面:啥也不干！
    return redirect("/scheduler/scheduler/?task_type=cron")

