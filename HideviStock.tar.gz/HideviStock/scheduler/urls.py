from django.urls import path,re_path
from django.conf import settings
from django.conf.urls.static import static

from . import views

app_name='scheduler'

urlpatterns = [
    path("scheduler/", views.scheduler, name='scheduler'),
    path("add_cron_job/",views.add_cron_job,name='add_cron_job'),
    path("add_tmp_job/",views.add_tmp_job,name='add_tmp_job'),
    path("job_remove/",views.job_remove,name='job_remove'),

]
