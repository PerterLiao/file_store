var navs = [{
	
	"title": "首页",
	"icon": "fa-cubes",
	"spread": true,
	"href": "main"
}, {
	"title": "数据中心",
	"icon": "fa-cogs",
	"spread": false,
	"children": [{
		"title": "股票列表",
		"icon": "fa-table",
		"href": "basic"
	}, {
		"title": "股票曾用名",
		"icon": "fa-table",
		"href": "namechange"
	}, {
		"title": "日线行情",
		"icon": "fa-table",
		"href": "daily"
	}, {
		"title": "每日指标",
		"icon": "fa-table",
		"href": "daily_basic"
	}, {
		"title": "利润表",
		"icon": "fa-table",
		"href": "income"
	}, {
		"title": "资产负债表",
		"icon": "fa-table",
		"href": "balancesheet"
	}, {
		"title": "现金流量表",
		"icon": "fa-table",
		"href": "cashflow"
	}, {
		"title": "业绩预告",
		"icon": "fa-table",
		"href": "forecast"
	}, {
		"title": "业绩快报",
		"icon": "fa-table",
		"href": "express"
	}, {
		"title": "财务指标数据",
		"icon": "fa-table",
		"href": "fina_indicator"
	}, {
		"title": "股权质押统计数据",
		"icon": "fa-table",
		"href": "pledge_stat"
	}, {
		"title": "股权质押明细数据",
		"icon": "fa-table",
		"href": "pledge_detail"
	}, {
		"title": "股东人数",
		"icon": "fa-table",
		"href": "stk_holdernumber"
	}]
}, {
	"title": "调度管理",
	"icon": "fa-address-book",
	"href": "",
	"spread": false,
	"children": [{
		"title": "调度历史",
		"icon": "&#xe63c;",
		"href": "btable.html"
	},{
		"title": "定时调度",
		"icon": "&#xe63c",
		"href": "begtable.html"
	}, {
		"title": "临时调度",
		"icon": "&#xe63c",
		"href": "btable.html"
	}]
}, {
	"title": "用户管理",
	"icon": "fa-stop-circle",
	"href": "user_list.html",
	"spread":true
}];

