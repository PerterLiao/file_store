from django.urls import path,re_path
from django.conf import settings
from django.conf.urls.static import static

from . import views

app_name='reader'

urlpatterns = [
    path('query/', views.query, name='query'),
    path('query_page/', views.query_page, name='query_page'),
    path('reader_main/', views.reader_main, name='reader_main'),

]
