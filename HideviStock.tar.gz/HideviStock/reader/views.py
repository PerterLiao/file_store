from django.shortcuts import render
import json
from django.core.serializers.json import DjangoJSONEncoder

from django.contrib import messages, auth
#from django.db.models import Max

from apscheduler.triggers.cron import CronTrigger
from django.shortcuts import render, redirect
from django.template import loader, context
from django.http import HttpResponse, HttpResponseNotFound
from django.apps import apps
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.clickjacking import xframe_options_sameorigin
from scheduler.utils import *

# Create your views here.

@login_required
@xframe_options_sameorigin
def reader_main(request):
    template = loader.get_template('index/base.html')
    context = {}
    return HttpResponse(template.render(context,request))

@login_required
@xframe_options_sameorigin
def query_page(request):
    table_name = request.GET.get("table_name",None)
    if not table_name:
        return HttpResponseNotFound("Not Found This Table !!!")
    table = apps.get_model("scheduler", table_name)
    #field_list = table._meta.df_fields.split(',')
    field_dicts = []
    field_list=[]
    for field in table._meta.fields:
        f_name = field.name
        if f_name != 'id' and f_name != 'primary_index':
            field_dicts.append({'field':f_name,'field_zh':field.verbose_name})
            field_list.append(f_name)
    context = {
        'table_name':table_name,
        'table_name_zh':table._meta.verbose_name,
        'field_dicts':field_dicts,
    }
    template=loader.get_template('reader/query.html')
    return HttpResponse(template.render(context, request))

@login_required
@xframe_options_sameorigin
def query(request):
    if request.method == 'GET':
        table_name = request.GET.get("table_name",None)
    else:
        table_name = request.POST.get("table_name",None)

    if table_name == None:
        return HttpResponseNotFound("Not Found This Table !!!")

    table = apps.get_model("scheduler", table_name)
    #field_list = table._meta.df_fields.split(',')
    field_dicts = []
    field_list=[]
    for field in table._meta.fields:
        f_name = field.name
        if f_name != 'id' and f_name != 'primary_index':
            field_dicts.append({'field':f_name,'field_zh':field.verbose_name})
            field_list.append(f_name)
    select_fields = request.POST.getlist("select_fields",field_list)
    data_date = request.POST.get('data_date',None)

    filter_fields = request.POST.getlist("filter_field",None)

    # filter_min可以作为索搜的单个值（如果没有最大值的话）
    filter_mins = request.POST.getlist("filter_min",None)
    filter_maxs = request.POST.getlist("filter_max",None)

    order_fields = request.POST.getlist("order_field",None)
    sort_methods = request.POST.getlist("sort_method",'')
    conditions = {}
    date_dict={}
    order_list = []
    result = table.objects.all()

    # 日期过滤
    print('data_date:'+str(data_date))
    if data_date is None:
        data_date=get_last_day()
        if table_name in ['namechange','income','balancesheet','cashflow','express','forecast','finaindicator','pledge_detail','stk_holdernumber','stk_holdertrade']:
            #result = result.annotate(ann_date=Max('ann_date')).order_by('-ann_date','ts_code')
            date_dict['ann_date']=data_date
        elif table_name in ['pledge_stat']:
            #result = result.annotate(ann_date=Max('end_date')).order_by('-end_date','ts_code')
            date_dict['end_date']=data_date
        elif table_name in ['daily','dailybasic']:
            #result = result.annotate(ann_date=Max('trade_date')).order_by('-trade_date','ts_code')
            date_dict['trade_date']=data_date
        else:
            pass
        result=result.filter(**date_dict)
    elif data_date != '':
        if table_name in ['namechange','income','balancesheet','cashflow','express','forecast','finaindicator','pledge_detail','stk_holdernumber','stk_holdertrade']:
            date_dict['ann_date']=data_date
        elif table_name in ['pledge_stat']:
            date_dict['end_date']=data_date
        elif table_name in ['daily','dailybasic']:
            date_dict['trade_date']=data_date
        else:
            pass
        result=result.filter(**date_dict)
    else:
        pass

    # condition 解析
    print('filter:'+str(filter_fields))
    condition_size=len(filter_fields)
    if condition_size >= 1 and filter_fields[0]!='':
        for i in range(condition_size):
            if filter_maxs[i] =='':
                conditions[filter_fields[i]+'__startswith'] = filter_mins[i]
            else :
                conditions[filter_fields[i]+'__range'] = [filter_mins[i],filter_maxs[i]]
        result = result.filter(**conditions)
    
    # order 解析
    print('sort:'+str(order_fields))
    sort_size = len(order_fields)
    if sort_size >=1 and order_fields[0]!="":
        for i in range(sort_size):
            order_list.append(sort_methods[i]+order_fields[i])
        result = result.order_by(*order_list)


    #result = result[:100]
    result_list = list(result.values(*select_fields))
    context = {
        'table_name':table_name,
        'table_name_zh':table._meta.verbose_name,
        'field_dicts':json.dumps(field_dicts),
        'select_fields':json.dumps(select_fields),
        "data": json.dumps(result_list,cls=DjangoJSONEncoder)
    }
    template=loader.get_template('reader/table.html')
    return HttpResponse(template.render(context, request))
