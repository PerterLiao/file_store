from django.urls import path,re_path
from django.conf import settings

from . import views

app_name='report'

urlpatterns = [
    path('get_report/', views.get_report, name='get_report'),
    path('get_report_stat/', views.get_report_stat, name='get_report_stat'),
    path('submit_report/', views.submit_report, name='submit_report'),
    path('exec_template/', views.exec_template, name='exec_template'),
    path('upload_market_segment/', views.upload_market_segment, name='upload_market_segment'),
]
