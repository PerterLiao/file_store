import xlrd
from django.shortcuts import render, redirect
from django.db import connection
from django.template import loader, context
from django.http import HttpResponse, HttpResponseNotFound
from django.apps import apps
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.clickjacking import xframe_options_sameorigin
import json
from django.core.serializers.json import DjangoJSONEncoder
from .models import *
from scheduler.utils import get_last_day

# Create your views here.

@login_required
@xframe_options_sameorigin
def get_report(request):
    basic_field_dict = get_field_dicts("basic")
    namechange_field_dict = get_field_dicts("namechange")
    daily_field_dict = get_field_dicts("daily")
    dailybasic_field_dict = get_field_dicts("dailybasic")
    income_field_dict = get_field_dicts("income")
    cashflow_field_dict = get_field_dicts("cashflow")
    balance_field_dict = get_field_dicts("balancesheet")
    forecast_field_dict = get_field_dicts("forecast")
    express_field_dict = get_field_dicts("express")
    fina_field_dict = get_field_dicts("finaindicator")
    stat_field_dict = get_field_dicts("pledge_stat")
    detail_field_dict = get_field_dicts("pledge_detail")
    stk_field_dict = get_field_dicts("stk_holdernumber")

    templates = list(ReportTemplate.objects.values())

    context = {
            "basic_field_dicts": basic_field_dict
            ,"namechange_field_dicts": namechange_field_dict
            ,"daily_field_dicts": daily_field_dict
            ,"dailybasic_field_dicts": dailybasic_field_dict
            ,"income_field_dicts": income_field_dict
            ,"cashflow_field_dicts": cashflow_field_dict
            ,"balance_field_dicts": balance_field_dict
            ,"forecast_field_dicts": forecast_field_dict
            ,"express_field_dicts": express_field_dict
            ,"fina_field_dicts": fina_field_dict
            ,"stat_field_dicts":stat_field_dict 
            ,"detail_field_dicts": detail_field_dict
            ,"stk_field_dicts": stk_field_dict
            ,"templates": templates
        }

    template=loader.get_template('report/report_custom.html')
    return HttpResponse(template.render(context, request))

@login_required
@xframe_options_sameorigin
def get_report_stat(request):
    if request.method ==  'GET':
        fields = Report_Stat._meta.fields
        field_names = {}
        for f in fields:
            field_names[f.name] = f.verbose_name

        data = []
        date=get_last_day()
        report_data = list(Report_Stat.objects.values().filter(report_date=date))
        for row in report_data:
            data.append(row)
        context = {
                'fields':json.dumps(field_names),
                'report_data':json.dumps(data,cls=DjangoJSONEncoder)
                }

    template=loader.get_template('report/report_stat.html')
    return HttpResponse(template.render(context, request))


def get_field_dicts(table_name=None):
    field_dicts = []
    table = apps.get_model("scheduler", table_name) 
    fields=table._meta.fields
    for field in fields:
        field_name = field.name
        if field_name != 'id' and field_name != 'primary_key':
            field_dicts.append({'field':field_name,'field_zh':field.verbose_name})
        
    return field_dicts

def get_fields_zh(table_name=None,select_fields=None):
    table = apps.get_model("scheduler", table_name) 
    fields=table._meta.fields
    fields_zh=[]
    for field in fields:
        field_name = field.name
        if field_name in select_fields:
            fields_zh.append(field.verbose_name)
    return fields_zh


@login_required
@xframe_options_sameorigin
def submit_report(request):
    if request.method == 'GET':
        return get_report(request)
    else:
        basic_fields = request.POST.getlist('basic_fields',[])
        namechange_fields = request.POST.getlist('namechange_fields',[])
        daily_fields = request.POST.getlist('daily_fields',[])
        dailybasic_fields = request.POST.getlist('dailybasic_fields',[])
        income_fields = request.POST.getlist('income_fields',[])
        balancesheet_fields = request.POST.getlist('balancesheet_fields',[])
        cashflow_fields = request.POST.getlist('cashflow_fields',[])
        express_fields = request.POST.getlist('express_fields',[])
        forecast_fields = request.POST.getlist('forecast_fields',[])
        finaindicator_fields = request.POST.getlist('finaindicator_fields',[])
        pledge_stat_fields = request.POST.getlist('pledge_stat_fields',[])
        pledge_detail_fields = request.POST.getlist('pledge_detail_fields',[])
        stk_holdernumber_fields = request.POST.getlist('stk_holdernumber_fields',[])
        template_name = request.POST.get('template_name','')

        table_fields_dict = {}
        fields_zh = []
        if len(basic_fields) > 0 :
            table_fields_dict['basic']=basic_fields
            fields_zh = fields_zh + get_fields_zh(table_name='basic',select_fields=basic_fields)

        if len(namechange_fields) > 0 :
            table_fields_dict['namechange']=namechange_fields
            fields_zh = fields_zh + get_fields_zh(table_name='namechange',select_fields=namechange_fields)
        if len(daily_fields) > 0 :
            table_fields_dict['daily']=daily_fields
            fields_zh = fields_zh + get_fields_zh(table_name='daily',select_fields=daily_fields)
        if len(dailybasic_fields) > 0 :
            table_fields_dict['dailybasic']=dailybasic_fields
            fields_zh = fields_zh + get_fields_zh(table_name='dailybasic',select_fields=dailybasic_fields)
        if len(income_fields) > 0 :
            table_fields_dict['income']=income_fields
            fields_zh = fields_zh + get_fields_zh(table_name='income',select_fields=income_fields)
        if len(balancesheet_fields) > 0 :
            table_fields_dict['balancesheet']=balancesheet_fields
            fields_zh = fields_zh + get_fields_zh(table_name='balancesheet',select_fields=balancesheet_fields)
        if len(cashflow_fields) > 0 :
            table_fields_dict['cashflow']=cashflow_fields
            fields_zh = fields_zh + get_fields_zh(table_name='cashflow',select_fields=cashflow_fields)
        if len(express_fields) > 0 :
            table_fields_dict['express']=express_fields
            fields_zh = fields_zh + get_fields_zh(table_name='express',select_fields=express_fields)
        if len(forecast_fields) > 0 :
            table_fields_dict['forecast']=forecast_fields
            fields_zh = fields_zh + get_fields_zh(table_name='forecast',select_fields=forecast_fields)
        if len(finaindicator_fields) > 0 :
            table_fields_dict['finaindicator']=finaindicator_fields
            fields_zh = fields_zh + get_fields_zh(table_name='finaindicator',select_fields=finaindicator_fields)
        if len(pledge_stat_fields) > 0 :
            table_fields_dict['pledge_stat']=pledge_stat_fields
            fields_zh = fields_zh + get_fields_zh(table_name='pledge_stat',select_fields=pledge_stat_fields)
        if len(pledge_detail_fields) > 0 :
            table_fields_dict['pledge_detail']=pledge_detail_fields
            fields_zh = fields_zh + get_fields_zh(table_name='pledge_detail',select_fields=pledge_detail_fields)
        if len(stk_holdernumber_fields) > 0 :
            table_fields_dict['stk_holdernumber']=stk_holdernumber_fields
            fields_zh = fields_zh + get_fields_zh(table_name='stk_holdernumber',select_fields=stk_holdernumber_fields)


        sql=get_sql(table_fields_dict)
        select_fields = [ t+'.'+field for t,fields in table_fields_dict.items() for field in fields]
        report_fields = '#'.join(fields_zh)
        report_fields_en = '#'.join(select_fields)
        #print(sql)
        if template_name !='':
            report_template=ReportTemplate(report_name=template_name,report_sql=sql,report_fields=report_fields,report_fields_en=report_fields_en)
            report_template.save()
            context = {}
            template = loader.get_template('report/report_ok.html')
        else:
            cur=connection.cursor()
            cur.execute(sql)
            report_data = list(cur.fetchall())
            cur.close()
            #report_data=json.loads(json.dumps(report_data,cls=DjangoJSONEncoder))
            data=[]
            for r in report_data:
                row = {}
                for i in range(len(select_fields)):
                    f=select_fields[i]
                    v=r[i]
                    row[f]=v
                data.append(row)

            context={
                    'select_fields':json.dumps(select_fields),
                    'select_fields_zh':json.dumps(fields_zh),
                    'report_data':json.dumps(data,cls=DjangoJSONEncoder)
                    }
            template = loader.get_template('report/report_table.html')
        return HttpResponse(template.render(context,request))
        

        
'''需要时间指定'''
def get_sql(table_fields_dict=None):
    if table_fields_dict is None or len(table_fields_dict) == 0:
        return ""
    else:
        select_fields = [ t+'.'+field for t,fields in table_fields_dict.items() for field in fields]
        tables = list(table_fields_dict.keys())
        sub_tables = get_sub_tables(table_fields=table_fields_dict)
        sql_select = "select "+",".join(select_fields) + ' from '
        join_str = sub_tables[tables[0]]
        for i in range(1,len(tables)):
            join_str = ' '+join_str+' join '+sub_tables[tables[i]] +' on '+tables[0]+'.ts_code='+tables[i]+'.ts_code '

        sql_str = sql_select  + join_str 

    return sql_str

def get_sub_tables(table_fields=None):
    table_date = {'namechange':'ann_date',
            'daily':'trade_date',
            'dailybasic':'trade_date',
            'income':'ann_date',
            'express':'ann_date',
            'balancesheet':'ann_date',
            'forecast':'ann_date',
            'cashflow':'ann_date',
            'finaindicator':'ann_date',
            'pledge_stat':'end_date',
            'pledge_detail':'ann_date',
            'stk_holdernumber':'ann_date'}
    sub_tables = {}
    for t,fields in table_fields.items():
        fields_str= ','.join(fields)
        sql=''
        if t in list(table_date.keys()):
            if 'ts_code' in fields:
                sql =  '(select {} ,max({}) from {} group by ts_code ) as {}'.format(fields_str,table_date[t],t,t)
            else:
                sql = '(select ts_code,{} ,max({}) from {} group by ts_code ) as {}'.format(fields_str,table_date[t],t,t)

        else:
            if 'ts_code' in fields:
                sql = '(select {} from {} ) as {}'.format(fields_str,t,t)
            else:
                sql = '(select ts_code,{} from {} ) as {}'.format(fields_str,t,t)
        sub_tables[t]=sql
    return sub_tables




            
        


@login_required
def exec_template(request):
    template = loader.get_template('report/exec_err.html')
    context = {}
    if request.method == "POST":
        name = request.POST.get('report_name','')
        if  name != '':
            report = ReportTemplate.objects.get(report_name=name)
            sql = report.report_sql
            fields_zh = report.report_fields.split('#')
            fields = report.report_fields_en.split('#')
            cur=connection.cursor()
            cur.execute(sql)
            report_data = list(cur.fetchall())
            cur.close()
            #report_data=json.loads(json.dumps(report_data,cls=DjangoJSONEncoder))
            data=[]
            for r in report_data:
                row = {}
                for i in range(len(fields)):
                    f=fields[i]
                    v=r[i]
                    row[f]=v
                data.append(row)

            context={
                    'select_fields':json.dumps(fields),
                    'select_fields_zh':json.dumps(fields_zh),
                    'report_data':json.dumps(data,cls=DjangoJSONEncoder)
                    }
            template = loader.get_template('report/report_table.html')
    return HttpResponse(template.render(context,request))

@login_required
def upload_market_segment(request):
    if request.method == "POST":
        market_file = request.FILES.get('market_segment_file')
        wb = xlrd.open_workbook(filename=None, file_contents=market_file.read())
        table = wb.sheets()[0]
        nrows = table.nrows  #行数
        ncole = table.ncols  #列数
        if ncole > 7 :
            template = loader.get_template('report/market_segment_err.html')
            return HttpResponse(template.render({},request))
        for x in range(1,nrows):
            row={'ts_code':'',
                'name':'',
                'market_segments_wind':'',
                'market_segments_cust1':'',
                'market_segments_cust2':'',
                'market':'',
                'area':''}
            fields = list(row.keys())
            for y in range(ncole):
                row[fields[y]]=table.cell_value(x,y)
            Market_Segment(**row).save()
            
        # 用完记得删除
        wb.release_resources()
        del wb
    return get_report_stat(request)

