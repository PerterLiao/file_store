from django.shortcuts import render
from django.contrib import messages, auth

from apscheduler.triggers.cron import CronTrigger
from django.shortcuts import render, redirect
from django.template import loader, context
from django.http import HttpResponse, HttpResponseNotFound
from django.apps import apps
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.clickjacking import xframe_options_sameorigin
import sys
sys.path.append('../index')
from index.views import index

# Create your views here.

def login(request):
    if request.method != 'POST':
        return render(request,'user/login.html')
    username = request.POST.get('username')
    password = request.POST.get('password')
    user_obj = auth.authenticate(username=username,password=password)
    if not user_obj :
        return redirect("user:login")
    else:
        auth.login(request,user_obj)
        return index(request)

def log_out(request):
    logout(request)
    return redirect('user:login')

@login_required
@xframe_options_sameorigin
def user_update(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            user_obj = User.objects.get(username=username)
            user_obj.set_password(password1)
            user_obj.save()
            auth.login(request,user_obj)
        else:
            messages.warning(request,'密码不一致')
            return HttpResponse('密码不一致')

        return render(request,'user/user_update.html')
    else:
        return render(request,'user/user_update.html')

